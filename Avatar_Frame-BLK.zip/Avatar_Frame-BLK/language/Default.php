<?php
$lang['frame_file'] = 'Select image';
$lang['frame_list'] = 'Frames';
$lang['frame_coins'] = 'Free price for this rank and above';
$lang['frame_up'] = 'Select frame image';
?>