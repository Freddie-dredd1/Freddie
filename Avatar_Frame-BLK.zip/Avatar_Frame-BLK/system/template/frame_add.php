<div class="pad15">
	<div class="modal_content">
		<div class="centered_element">
			<div class="tpad20">
				<div class="setting_element">
                   <p class="label"><?php echo $lang['frame_file']; ?></p>
                    <input id="set_file" class="full_input" type="file"/>
                </div> 
			</div>
			<div class="tpad20 bpad10">
				<div class="btable_auto mauto">
					<div class="gift_selicon bcell_mid">
						<img src="default_images/icons/gold.svg">
					</div>
					<div id="gift_pricing" class="gift_pricing hpad5 bcell_mid">
					    <div class="setting_element ">
                            <input id="add_price" class="full_input"  type="text" value=""/>
                        </div>
					</div>
				</div>
			</div>
		</div>
	<div class="modal_control centered_element bpad20">
		<button onclick="add_frame();" class="reg_button theme_btn"><?php echo $lang['save']; ?></button>
		<button class="reg_button default_btn cancel_modal"><?php echo $lang['cancel']; ?></button>
	</div>
	</div>
</div>