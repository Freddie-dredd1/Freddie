<div class="pad15">
	<div class="modal_content">
		<div class="centered_element">
			<div class="tpad20">
				<img class="gift_selected" id="gift_selected" src="addons/<?php echo $addons['addons']; ?>/files/frames/<?php echo $boom['tumb']; ?>">
			</div>
			<div class="tpad20 bpad10">
				<div class="btable_auto mauto">
					<div class="gift_selicon bcell_mid">
						<img src="default_images/icons/gold.svg">
					</div>
					<div id="gift_pricing" class="gift_pricing hpad5 bcell_mid">
					    <div class="setting_element ">
                            <input id="set_price" class="full_input"  type="text" value="<?php echo $boom['price']; ?>"/>
                        </div>
					</div>
				</div>
			</div>
		</div>
		<div class="modal_control centered_element bpad20">
			<button onclick="save_frame(<?php echo $boom['id']; ?>);" class="reg_button theme_btn"><?php echo $lang['save']; ?></button>
			<button onclick="delete_frame(<?php echo $boom['id']; ?>);" class="reg_button delete_btn"><?php echo $lang['delete']; ?></button>
			<button class="reg_button default_btn cancel_modal"><?php echo $lang['cancel']; ?></button>
		</div>
	</div>
</div>