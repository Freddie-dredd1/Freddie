<div class="pad15">
	<div class="modal_content">
		<div class="centered_element">
			<div class="tpad20">
				<img class="gift_selected" id="gift_selected" src="addons/<?php echo $data['addons']; ?>/gifts/<?php echo $boom['tumb']; ?>">
			</div>
			<div id="gift_title" class="text_med bold tpad20"><?php echo $boom['name']; ?></div>
			<div class="gift_text sub_text"><?php echo $boom['info']; ?></div>
			<div class="tpad20 bpad10">
				<div class="btable_auto mauto">
					<div class="gift_selicon bcell_mid">
						<img src="addons/<?php echo $data['addons']; ?>/files/gold.svg">
					</div>
					<div id="gift_pricing" class="gift_pricing hpad5 bcell_mid"><?php echo $boom['price']; ?></div>
				</div>
			</div>
		</div>
	</div>
</div>