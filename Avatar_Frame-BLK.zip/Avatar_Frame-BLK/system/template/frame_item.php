<div class="post_input_container bhover gcard select_gift gift_bg" data-img="addons/<?php echo ADDON; ?>/files/frames/<?php echo $boom['tumb']; ?>" data-price="<?php echo $boom['price']; ?>" data-id="<?php echo $boom['id']; ?>">
	<img class="gcard_img lazy" data-src="addons/<?php echo ADDON; ?>/files/frames/<?php echo $boom['tumb']; ?>" src="<?php echo imgLoader(); ?>">
	<div class="btable_auto gcard_price gtag input_wrap">
		<div class="bcell_mid text_small">
			<div class="btable_auto">
				<div class="bcell_mid gcard_pwrap">
					<img src="default_images/icons/gold.svg">
				</div>
				<div class="bcell_mid hpad3 bold"><?php echo $boom['price']; ?></div>
			</div>
		</div>
	</div>
</div>