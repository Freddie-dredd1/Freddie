<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
<style>
	.gift_msg {
		background: #fdf9ee;
		color: #080703;
		padding: 1px 10px;
		border-radius: 10px 0 10px 10px;
		box-shadow: 0px 1px 5px #bfbfbfa6;
		border: 1px dashed #00ccff;
		margin-top: 5px;
	}

	.gift_bg {
		/* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#e9f6fd+0,d3eefb+100;Blue+3D+%233 */
		background: rgb(233, 246, 253);
		/* Old browsers */
		background: -moz-linear-gradient(top, rgba(233, 246, 253, 1) 0%, rgba(211, 238, 251, 1) 100%);
		/* FF3.6-15 */
		background: -webkit-linear-gradient(top, rgba(233, 246, 253, 1) 0%, rgba(211, 238, 251, 1) 100%);
		/* Chrome10-25,Safari5.1-6 */
		background: linear-gradient(to bottom, rgba(233, 246, 253, 1) 0%, rgba(211, 238, 251, 1) 100%);
		/* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#e9f6fd', endColorstr='#d3eefb', GradientType=0);
		/* IE6-9 */
		border: 1px dashed #a8c9d2;
		border-radius: 25px;
		box-shadow: 0 6px 10px #d2d2d2cc;

	}

	.gift_bg .username {
		color: black;
	}
</style>
<?php if (boomAllow($addons['addons_access'])) {
	$bbfv = boomFileVersion();
?>
	<script data-cfasync="false" type="text/javascript">
		$(document).ready(function() {
			appLeftMenu('shopping-basket', 'chat store', 'showChatStore();');
			$("<div onclick='showChatStore();' class='head_option'><i class='fa fa-shopping-basket'></i><p style='font-size: 11px;'> Store. </p></div>").insertBefore("#get_private");

			showChatStore = function() {
				$.post('addons/chat_store/system/sw_chat_store.php', {
					token: utk,
				}, function(response) {
					if (response == 0) {
						callSaved(system.error, 3);
					} else {
						overModal(response);
					}
				});
			}
			buyStoreMemberVip = function() {
				$.post('addons/chat_store/system/action_store.php', {
					buy_vip_store: 1,
					token: utk,
				}, function(response) {
					if (response == 1) {
callSaved('Membership purchased successfully, page will be refreshed', 1);
						location.reload();
					} else if (response == 2) {
						callSaved('You dont have enough coins to buy', 3);
					} else if (response == 3) {
              callSaved('Your current membership is higher than this one', 3); 
					} else if (response == 4) {
callSaved('You must register first', 3);
					} else if (response == 5) {
callSaved('Your level is less than required to buy', 3);
					} else if (response == 7) {
						callSaved('You are trying to buy a rank you already own', 3);

					} else {
						callSaved(system.error, 3);
					}
				});
			}
			buyStoreMemberMod = function() {
				$.post('addons/chat_store/system/action_store.php', {
					buy_mod_store: 1,
					token: utk,
				}, function(response) {
					if (response == 1) {
callSaved('Membership purchased successfully, page will be refreshed', 1);
						location.reload();
					} else if (response == 2) {
						callSaved('You dont have enough coins to buy', 3);
					} else if (response == 3) {
              callSaved('Your current membership is higher than this one', 3); 
					} else if (response == 4) {
callSaved('You must register first', 3);
					} else if (response == 5) {
callSaved('Your level is less than required to buy', 3);
					} else if (response == 7) {
						callSaved('You are trying to buy a rank you already own', 3);
					} else {
						callSaved(system.error, 3);
					}
				});
			}
			buyStoreMemberAdm = function() {
				$.post('addons/chat_store/system/action_store.php', {
					buy_adm_store: 1,
					token: utk,
				}, function(response) {
					if (response == 1) {
callSaved('Membership purchased successfully, page will be refreshed', 1);						location.reload();
					} else if (response == 2) {
						callSaved('You dont have enough coins to buy', 3);
					} else if (response == 3) {
						callSaved('Your current membership is higher than this one', 3);
					} else if (response == 4) {
						callSaved('You must register first', 3);
					} else if (response == 5) {
						callSaved('Your level is less than required to buy', 3);
					} else if (response == 7) {
						callSaved('You are trying to buy a rank you already own', 3);
					} else {
						callSaved(system.error, 3);
					}
				});
			}
			buyStorePrem7 = function() {
				$.post('addons/chat_store/system/action_store.php', {
					buy_prem7_store: 1,
					token: utk,
				}, function(response) {
					if (response == 1) {
callSaved('Membership purchased successfully, page will be refreshed', 1);						location.reload();
					} else if (response == 2) {
						callSaved('You dont have enough coins to buy', 3);
					} else if (response == 3) {
						callSaved('Your current membership is higher than this one', 3);
					} else if (response == 4) {
						callSaved('You must register first', 3);
					} else if (response == 5) {
						callSaved('Your level is less than required to buy', 3);
					} else if (response == 6) {
						callSaved('انت تمتلك عضوية بريميم بالفعل', 3);
					} else {
						callSaved(system.error, 3);
					}
				});
			}
			buyStorePrem15 = function() {
			    $.post('addons/chat_store/system/MA_action.php', {
					buy_prem15_store: 1,
					token: utk,
				}, function(response) {
					if (response == 1) {
callSaved('Membership purchased successfully, page will be refreshed', 1);						location.reload();
					} else if (response == 2) {
						callSaved('You dont have enough coins to buy', 3);
					} else if (response == 3) {
						callSaved('Your current membership is higher than this one', 3);
					} else if (response == 4) {
						callSaved('You must register first', 3);
					} else if (response == 5) {
						callSaved('Your level is less than required to buy', 3);
					} else if (response == 6) {
						callSaved('انت تمتلك عضوية بريميم بالفعل', 3);
					} else {
						callSaved(system.error, 3);
					}
				});
			}
			buyStorePrem30 = function() {
				$.post('addons/chat_store/system/action_store.php', {
					buy_prem30_store: 1,
					token: utk,
				}, function(response) {
					if (response == 1) {
callSaved('Membership purchased successfully, page will be refreshed', 1);						location.reload();
					} else if (response == 2) {
						callSaved('You dont have enough coins to buy', 3);
					} else if (response == 3) {
						callSaved('Your current membership is higher than this one', 3);
					} else if (response == 4) {
						callSaved('You must register first', 3);
					} else if (response == 5) {
						callSaved('Your level is less than required to buy', 3);
					} else if (response == 6) {
						callSaved('انت تمتلك عضوية بريميم بالفعل', 3);
					} else {
						callSaved(system.error, 3);
					}
				});
			}
		});
	</script>
<?php } ?>
<script data-cfasync="false" src="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.1/spectrum.min.js<?php echo $bbfv; ?>"></script>
<script data-cfasync="false" type="text/javascript">
	$(document).ready(function() {
		boomAddCss('addons/chat_store/files/store.css');
		boomAddCss('addons/chat_store/files/spectrum.css');
		<?php if ($data['user_prim'] > 0 || $data['prim_plus'] > 0) { ?>
			$("<div onclick='showPrimOptions();' class='head_option'><i class='fa fa-cogs'></i><p style='font-size: 11px;'> customize. </p></div>").insertBefore("#get_private");
		<?php } ?>
		$("<div onclick='showTopLevels();' class='chat_footer_item'><i class='i_btm fa fa-diamond'></i><p style='font-size: 11px;'> Levels. </p></div>").insertBefore("#dpriv");
		$("<div onclick='showTopCoins();' class='chat_footer_item'><i class='i_btm fa fa-btc'></i><p style='font-size: 11px;'> Coins. </p></div>").insertBefore("#dpriv");
		$(document).on('click', '.pro_choice', function() {
			var curColor = $(this).attr('data');
			if ($('.my_pro_color').attr('data') == curColor) {
				$('.bccheck').remove();
				$('.my_pro_color').attr('data', '');
				saveProColor('user');
			} else {
				$('.bccheck').remove();
				$(this).append('<i class="bccheck fa fa-check"></i>');
				$('.my_pro_color').attr('data', curColor);
				saveProColor(curColor);
			}
		});
		$(document).on('click', '.pro_shadow', function() {
			var curColor = $(this).attr('data');
			if ($('.my_pro_shadow').attr('data') == curColor) {
				$('.bccheck').remove();
				$('.my_pro_shadow').attr('data', '');
				saveProShadow('user');
			} else {
				$('.bccheck').remove();
				$(this).append('<i class="bccheck fa fa-check"></i>');
				$('.my_pro_shadow').attr('data', curColor);
				saveProShadow(curColor);
			}
		});
		$(document).on('click', '.pic_shadow', function() {
			var curColor = $(this).attr('data');
			if ($('.my_pic_shadow').attr('data') == curColor) {
				$('.bccheck').remove();
				$('.my_pic_shadow').attr('data', '');
				savePicShadow('user');
			} else {
				$('.bccheck').remove();
				$(this).append('<i class="bccheck fa fa-check"></i>');
				$('.my_pic_shadow').attr('data', curColor);
				savePicShadow(curColor);
			}
		});

		showTopLevels = function() {
			$.post('addons/chat_store/system/show_top_levels.php', {
				token: utk,
			}, function(response) {
				showModal(response, 500);
			});
		}
		showTopCoins = function() {
			$.post('addons/chat_store/system/show_top_coins.php', {
				token: utk,
			}, function(response) {
				showModal(response, 500);
			});
		}
		// Premium features
		saveNameColors = function() {
			$.post('addons/chat_store/system/MA_action.php', {
				my_username_color: $('.user_color').attr('data'),
				token: utk,
			}, function(response) {
				if (response == 1) {
					callSaved(system.saved, 1);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		saveNameGlow = function() {
			$.post('addons/chat_store/system/MA_action.php', {
				my_username_glow: $('#name_glow_color').val(),
				token: utk,
			}, function(response) {
				if (response == 1) {
					callSaved(system.saved, 1);
					userReload(1);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		saveFancySystem = function() {
			$.post('addons/chat_store/system/MA_action.php', {
				set_fancy_name: $('#set_fancy_name').val(),
				fancy_font_style: $('#fancy_font_style').val(),
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('Decoration settings saved', 1);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		delFancySystem = function() {
			$.post('addons/chat_store/system/MA_action.php', {
				delete_fancy_system: '',
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('Decoration settings saved', 1);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		var waitAvatarSong = 0;
		uploadProfileSong = function() {
			var file_data = $("#pro_song").prop("files")[0];
			if ($("#pro_song").val() === "") {
				callSaved('You must select a song first', 3);
			} else {
				if (waitAvatarSong == 0) {
					waitAvatarSong = 1;
					uploadIcon('avat_icon_song', 1);
					var form_data = new FormData();
					form_data.append("file", file_data)
					form_data.append("token", utk)
					$.ajax({
						url: "addons/chat_store/system/action_song.php",
						dataType: 'json',
						cache: false,
						contentType: false,
						processData: false,
						data: form_data,
						type: 'post',
						success: function(response) {
							if (response == 1) {
								callSaved('This file cannot be loaded', 3);
							} else if (response == 5) {
								callSaved('The song was uploaded successfully', 1);
							} else {
								callSaved('Error loading', 3);
							}
							uploadIcon('avat_icon_song', 2);
							waitAvatarSong = 0;
						},
						error: function() {
							callSaved('Error loading', 3);
							uploadIcon('avat_icon_song', 2);
							waitAvatarSong = 0;
						}
					})
				} else {
					return false;
				}
			}
		}
		delProfileSong = function() {
			$.post('addons/chat_store/system/MA_action.php', {
				delete_profile_song: 1,
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		saveNameWings = function(wing1, wing2) {
			$.post('addons/chat_store/system/MA_action.php', {
				set_wing1: wing1,
				set_wing2: wing2,
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);
					userReload(1);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		delNameWings = function() {
			$.post('addons/chat_store/system/MA_action.php', {
				delete_name_wings: 1,
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		saveProColor = function(newColor) {
			$.post('addons/chat_store/system/action_features.php', {
				my_newpro_color: newColor,
				token: utk,
			}, function(response) {
				callSaved('settings saved', 1);
			});
		}
		saveProShadow = function(newColor) {
			$.post('addons/chat_store/system/action_features.php', {
				my_newpro_shadow: newColor,
				token: utk,
			}, function(response) {
				callSaved('settings saved', 1);
			});
		}
		saveProSettings = function() {
			$.post('addons/chat_store/system/MA_action.php', {
				pro_main_color: $('#pro_text_main').val(),
				pro_sub_color: $('#pro_text_sub').val(),
				pro_menu_color: $('#pro_text_menu').val(),
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);;
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		delProColors = function() {
            $.post('addons/chat_store/system/MA_action.php', {
				delete_profile_colors: 1,
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);;
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		var waitProBackground = 0;
		uploadProBackground = function() {
			var file_data = $("#pro_background").prop("files")[0];
			if ($("#pro_background").val() === "") {
				callSaved(system.noFile, 3);
			} else {
				if (waitProBackground == 0) {
					waitProBackground = 1;
					uploadIcon('pro_bg_icon', 1);
					var form_data = new FormData();
					form_data.append("file", file_data)
					form_data.append("token", utk)
					$.ajax({
						url: "addons/chat_store/system/profile_background.php",
						dataType: 'json',
						cache: false,
						contentType: false,
						processData: false,
						data: form_data,
						type: 'post',
						success: function(response) {
							if (response == 1) {
								callSaved(system.wrongFile, 3);
							} else if (response == 5) {
								callSaved(system.saved, 1);
							} else {
								callSaved('saved', 3);
							}
							uploadIcon('pro_bg_icon', 2);
							waitProBackground = 0;
						},
						error: function() {
							callSaved(system.error, 3);
							uploadIcon('pro_bg_icon', 2);
							waitProBackground = 0;
						}
					})
				} else {
					return false;
				}
			}
		}
		saveNameSmile = function(smile) {
			$.post('addons/chat_store/system/MA_action.php', {
				set_name_smile: smile,
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);;
					userReload(1);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		delNameSmile = function() {
			$.post('addons/chat_store/system/action_features.php', {
				delete_name_smile: 1,
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);;
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		var waitAvatarGif = 0;
		uploadAvatarGif = function() {
			var file_data = $("#gif_avatar").prop("files")[0];
			if ($("#gif_avatar").val() === "") {
				callSaved(system.noFile, 3);
			} else {
				if (waitAvatarGif == 0) {
					waitAvatarGif = 1;
					uploadIcon('avat_icon_gif', 1);
					var form_data = new FormData();
					form_data.append("file", file_data)
					form_data.append("token", utk)
					$.ajax({
						url: "addons/chat_store/system/profile_gif.php",
						dataType: 'json',
						cache: false,
						contentType: false,
						processData: false,
						data: form_data,
						type: 'post',
						success: function(response) {
							if (response == 1) {
								callSaved(system.wrongFile, 3);
							} else if (response == 5) {
								callSaved(system.saved, 1);
							} else {
								callSaved(system.error, 3);
							}
							uploadIcon('avat_icon_gif', 2);
							waitAvatarGif = 0;
						},
						error: function() {
							callSaved(system.error, 3);
							uploadIcon('avat_icon_gif', 2);
							waitAvatarGif = 0;
						}
					})
				} else {
					return false;
				}
			}
		}
		saveProfileSocial = function() {
			 $.post('addons/chat_store/system/MA_action.php', {
				set_pro_fb: $('#set_pro_fb').val(),
				set_pro_insta: $('#set_pro_insta').val(),
				set_pro_tw: $('#set_pro_tw').val(),
				set_pro_wp: $('#set_pro_wp').val(),
				set_pro_phone: $('#set_pro_phone').val(),
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);;
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		savePicShadow = function(newColor) {
			$.post('addons/chat_store/system/action_features.php', {
				my_newpic_color: newColor,
				token: utk,
			}, function(response) {
				hideOver();
			});
		}
		delPicShadow = function() {
			$.post('addons/chat_store/system/action_features.php', {
				delete_pic_shadow: 1,
				token: utk,
			}, function(response) {
				hideOver();
			});
		}
		savePhotoFrame = function(frame) {
			$.post('addons/chat_store/system/action_features.php', {
				set_photo_frame: frame,
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);;
					userReload(1);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		delPhotoFrame = function() {
			$.post('addons/chat_store/system/action_features.php', {
				delete_photo_frame: 1,
				token: utk,
			}, function(response) {
				hideOver();
			});
		}
		saveNameSpBg = function() {
			$.post('addons/chat_store/system/action_features.php', {
				sp_bg: $('#set_sp_bg_width').val(),
				sp_bg_width: $('#set_sp_bg:checked').val(),
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);;
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		delNameSpBg = function() {
			$.post('addons/chat_store/system/action_features.php', {
				del_sp_bg: 1,
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved('settings saved', 1);;
				} else {
					callSaved(system.error, 3);
				}
			});
		}

		// End Premium Features ========================================>
		// ----------------------->
		// =============================================================

		// show premium options
		showPrimOptions = function() {
			$.post('addons/chat_store/system/prim_options.php', {
				token: utk,
			}, function(response) {
				if (response == 0) {
					callSaved(system.error, 3);
				} else {
					overModal(response, 500);
				}
			});
		}
		// show premium plus options
		showPrimPlusOptions = function() {
			$.post('addons/chat_store/system/prim_plus_options.php', {
				token: utk,
			}, function(response) {
				if (response == 0) {
					callSaved(system.error, 3);
				} else {
					overModal(response);
				}
			});
		}
		// upgrade user to premium
		upgradeToPremium = function(u) {
			$.post('addons/chat_store/system/admin_upgrade_premium.php', {
				target: u,
				token: utk,
			}, function(response) {
				if (response == 0) {
					callSaved(system.error, 3);
				} else {
					overModal(response);
				}
			});
		}
		upgradeUserPremium = function(target) {
			$.post('addons/chat_store/system/action.php', {
				premium_plan: $('#upgrade_premium_user').val(),
				premium_target: target,
				token: utk
			}, function(response) {
				callSaved('Membership changed', 1);
				hideOver();
			});
		}
		upgradeUserPremiumPlus = function(target) {
			$.post('addons/chat_store/system/action.php', {
				premium_plus_plan: $('#upgrade_premiumplus_user').val(),
				premium_plus_target: target,
				token: utk
			}, function(response) {
				callSaved('Membership changed', 1);
				hideOver();
			});
		}
		// Developer Mode
		saveDeveloperSetting = function(id) {
			$.post('addons/chat_store/system/action.php', {
				setdev_coins: $('#dev_usercoins').val(),
				setdev_level: $('#dev_userlevel').val(),
				setdev_target: id,
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved(system.saved, 1);
				}
			});
		}
		premiumClean = function() {
			$.post('addons/chat_store/system/premium_clean.php', {
				clean_premium: 1,
				token: utk,
			}, function(response) {});
		}
		premiumPlusClean = function() {
			$.post('addons/chat_store/system/premium_plus_clean.php', {
				clean_premium_plus: 1,
				token: utk,
			}, function(response) {});
		}
		membersClean = function() {
			$.post('addons/chat_store/system/members_clean.php', {
				clean_members: 1,
				token: utk,
			}, function(response) {});
		}
		// show coins trans
		showCoinsTrans = function(source) {
			var target = $(source).attr('data');
			$.post('addons/chat_store/system/coins_trans.php', {
				target: target,
				token: utk,
			}, function(response) {
				showModal(response);
				closeTrigger();
			});
		}
		sendMyCoins = function() {
			$.post('addons/chat_store/system/action.php', {
				send_coins: $('#send_my_coins').val(),
				target: $('#target').val(),
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved(system.saved, 1);
				} else if (response == 2) {
					callSaved(system.error, 3);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		takeMyCoins = function() {
			$.post('addons/chat_store/system/action.php', {
				take_coins: $('#take_my_coins').val(),
				target: $('#target').val(),
				token: utk
			}, function(response) {
				if (response == 1) {
					callSaved(system.saved, 1);
				} else if (response == 2) {
					callSaved(system.error, 3);
				} else {
					callSaved(system.error, 3);
				}
			});
		}
		

	});
	$(document).ready(function() {
		$(document).on('click', '.ch_logs .copy_gift_code', function() {
			var copyGift = $(this).attr('data');
			emoticon('content', copyGift);
		});
		$(document).on('click', '.post_content .copy_gift_code', function() {
			var copyGift = $(this).attr('data');
			emoticon('content', copyGift);
		});
		$(document).on('click', '.name_choices, .choice', function() {
			var curColor = $(this).attr('data');
			if ($('.user_color').attr('data') == curColor) {
				$('.bccheck').remove();
				$('.user_color').attr('data', 'user');
				saveNameColors();
			} else {
				$('.bccheck').remove();
				$(this).append('<i class="fa fa-check bccheck"></i>');
				$('.user_color').attr('data', curColor);
				saveNameColors();
			}
			userReload(1);
		});
		$(document).on('click', '.name_shadow, .choice', function() {
			var curColor = $(this).attr('data');
			if ($('.user_color').attr('data') == curColor) {
				$('.bccheck').remove();
				$('.user_color').attr('data', 'user');
				saveNameGlow();
			} else {
				$('.bccheck').remove();
				$(this).append('<i class="fa fa-check bccheck"></i>');
				$('.user_color').attr('data', curColor);
				saveNameGlow();
			}
			userReload(1);
		});
		cleanPremium = setInterval(premiumClean, 1200000);
		premiumClean();
		cleanPremiumPlus = setInterval(premiumPlusClean, 1200000);
		premiumPlusClean();
		cleanMembers = setInterval(membersClean, 1200000);
		membersClean();
		$(".avstaff").append("<div data='' onclick='showCoinsTrans(this)' class='avset avitem rcoins'><span class='list_icon'><i class='fa fa-btc error'></i></span>Coins</div>");
		$(".avother").append("<div data='' onclick='showCoinsTrans(this)' class='avset avitem rcoins'><span class='list_icon'><i class='fa fa-btc error'></i></span>Coins</div>");
		$(".avroomstaff").append("<div data='' onclick='showCoinsTrans(this)' class='avset avitem rcoins'><span class='list_icon'><i class='fa fa-btc error'></i></span>Coins</div>");
	});
</script>