<?php
$lang['limit_use'] = 'الحد من استخدام كرسي الاعتراف لرتبة';
$lang['search_korsy'] = 'Your current membership is higher than this one�';
$lang['enter_name_onkorsy'] = 'ادخل اسم ضيف كرسي الاعتراف';
$lang['onkorsy'] = 'ضيف كرسي الاعتراف';
?>