<?php
$lang['video_post_chat'] = 'Post the chat';
$lang['video_post_private'] = 'Publish to private';
?>