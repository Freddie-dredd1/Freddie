<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');


// 


// UserName Smilies

if(isset($_POST['set_name_smile'])){
    $smile = escape($_POST['set_name_smile']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET name_smile = '$smile' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}


// Moving COlors or Username Colors

if(isset($_POST['my_username_color'])){
    $fancy = escape($_POST['my_username_color']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET user_color = '$fancy nameWave' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}

// Name Glow

if(isset($_POST['my_username_glow'])){
    $nameglow = escape($_POST['my_username_glow']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET name_glow = '$nameglow' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}


// decoration for your name

if(isset($_POST['set_fancy_name'])){
    $fancyname = escape($_POST['set_fancy_name']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET fancy_name = '$fancyname' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}

if(isset($_POST['delete_fancy_system'])){
    $fancyname = escape($_POST['delete_fancy_system']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET fancy_name = '$fancyname', name_wing1 = '', name_wing2 = '' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}


// Name Wings or Distinctive shapes

if(isset($_POST['set_wing1'], $_POST['set_wing2'])){
    $wing1 = escape($_POST['set_wing1']);
    $wing2 = escape($_POST['set_wing2']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET name_wing1 = '$wing1', name_wing2 = '$wing2' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}


// Main SubText Profile Colors

if(isset($_POST['pro_main_color'], $_POST['pro_sub_color'], $_POST['pro_menu_color'])){
    $maincolor = escape($_POST['pro_main_color']);
    $subtext = escape($_POST['pro_sub_color']);
    $menucolor = escape($_POST['pro_menu_color']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET pro_text_main = '$maincolor', pro_text_sub = '$subtext', pro_text_menu = '$menucolor' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}


// Delete Profile

if(isset($_POST['delete_profile_colors'])){
    $delprocolor = escape($_POST['delete_profile_colors']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET pro_text_main = '', pro_text_sub = '', pro_text_menu = '' pro_color = '', pro_shadow = '', pro_background = '' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}



// Social Profile Like fb insta whtsapp phone number twitter

if(isset($_POST['set_pro_fb'], $_POST['set_pro_insta'], $_POST['set_pro_tw'], $_POST['set_pro_wp'], $_POST['set_pro_phone'])){
    $profb = escape($_POST['set_pro_fb']);
    $proinsta = escape($_POST['set_pro_insta']);
    $protw = escape($_POST['set_pro_tw']);
    $prowp = escape($_POST['set_pro_wp']);
    $prophone = escape($_POST['set_pro_phone']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET pro_fb = '$profb', pro_insta = '$proinsta', pro_tw = '$protw', pro_wp = '$prowp', pro_phone = '$prophone' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}


// Permium Action

if(isset($_POST['buy_prem15_store'])){
    $prime = escape($_POST['buy_prem15_store']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET user_prim = '$prime' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}


if(isset($_POST['delete_profile_song'])){
    $delsong = escape($_POST['delete_profile_song']);
    if(!boomAllow($data['addons_access'])){
        die();
    }
    $mysqli->query("UPDATE boom_users SET pro_song = '' WHERE user_id = '{$data['user_id']}'");
	echo 1;
}


?>