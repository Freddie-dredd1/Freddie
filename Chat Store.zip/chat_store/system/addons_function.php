<?php
require_once('../../../system/config_addons.php');

// premium reset
function resetUserPrim($user){
    global $mysqli, $data;
    if($data['prim_plus'] == 0){
		$mysqli->query("UPDATE boom_users SET user_color = 'user', fancy_name = '', pro_color = '', pro_shadow = '', pro_song = '', pro_fb = '', pro_insta = '', pro_tw = '', pro_wp = '', pro_phone = '', name_smile = '0', name_wing1 = '', name_wing2 = '',
		pro_text_main = '', pro_text_sub = '', pro_text_menu = '', pro_background = '' WHERE user_id = '{$user['user_id']}'");
	}
}
// premium plus reset
function resetUserPrimPlus($user){
    global $mysqli;
    $mysqli->query("UPDATE boom_users SET user_color = 'user', fancy_name = '', pro_color = '', pro_shadow = '', pro_song = '', pro_fb = '', pro_insta = '', pro_tw = '', pro_wp = '', pro_phone = '', pic_shadow = '', name_smile = '0', name_wing1 = '', name_wing2 = '', photo_frame = '',
		pro_text_main = '', pro_text_sub = '', pro_text_menu = '', pro_background = '', private_profile = '0', sp_bg = '', sp_bg_width = '0' WHERE user_id = '{$user['user_id']}'");
}
// can manage premium features
function canManagePremium(){
	global $data;
	if( $data['user_prim'] > 0 || $data['prim_plus'] > 0 || $data['user_prim'] == 0 && $data['prim_plus'] > 0){
		return true;
	}
}
function chooseStoreItem($id){
	global $mysqli;
	$loadd = '';
	$get_store = $mysqli->query("SELECT * FROM boom_store WHERE store_id = '$id'");
	if($get_store->num_rows > 0){
		while($store = $get_store->fetch_assoc()){
			$loadd = $store['store_name'];
		}
	}
	else {
    	return false;
	}
	return $loadd;
}
function chooseStoreItemPrice($id){
	global $mysqli;
	$loadd = '';
	$get_store = $mysqli->query("SELECT * FROM boom_store WHERE store_id = '$id'");
	if($get_store->num_rows > 0){
		while($store = $get_store->fetch_assoc()){
			$loadd = $store['store_price'];
		}
	}
	else {
    	return false;
	}
	return $loadd;
}
function chooseStoreItemInfo($id){
	global $mysqli;
	$loadd = '';
	$get_store = $mysqli->query("SELECT * FROM boom_store WHERE store_id = '$id'");
	if($get_store->num_rows > 0){
		while($store = $get_store->fetch_assoc()){
			$loadd = $store['store_info'];
		}
	}
	else {
    	return false;
	}
	return $loadd;
}
function chooseStoreItemLevel($id){
	global $mysqli;
	$loadd = '';
	$get_store = $mysqli->query("SELECT * FROM boom_store WHERE store_id = '$id'");
	if($get_store->num_rows > 0){
		while($store = $get_store->fetch_assoc()){
			$loadd = $store['store_level'];
		}
	}
	else {
    	return false;
	}
	return $loadd;
}
function chooseStoreItemRank($id){
	global $mysqli;
	$loadd = '';
	$get_store = $mysqli->query("SELECT * FROM boom_store WHERE store_id = '$id'");
	if($get_store->num_rows > 0){
		while($store = $get_store->fetch_assoc()){
			$loadd = $store['store_rank'];
		}
	}
	else {
    	return false;
	}
	return $loadd;
}
function exChooseStoreItemTime($id){
	global $mysqli;
	$loadd = '';
	$get_store = $mysqli->query("SELECT * FROM boom_store WHERE store_id = '$id'");
	if($get_store->num_rows > 0){
		while($store = $get_store->fetch_assoc()){
			$loadd = $store['store_time'];
		}
	}
	else {
    	return false;
	}
	return $loadd;
}
function storeItemTime($id){
	global $mysqli, $data, $lang;
	$loadd = '';
	$get_store = $mysqli->query("SELECT * FROM boom_store WHERE store_id = '$id'");
	if($get_store->num_rows > 0){
		while($store = $get_store->fetch_assoc()){
		    if($store['store_time'] == 1){
		        $loadd = '7 Days';
		    }
		    if($store['store_time'] == 2){
		        $loadd = '15 Days';
		    }
		    if($store['store_time'] == 3){
		        $loadd = '30 Days';
			}
		}
	}
	else {
    	return false;
	}
	return $loadd;
}
function chooseStoreItemTime($id){
	global $mysqli, $data, $lang;
	$loadd = '';
	$get_store = $mysqli->query("SELECT * FROM boom_store WHERE store_id = '$id'");
	if($get_store->num_rows > 0){
		while($store = $get_store->fetch_assoc()){
			if($store['store_time'] == 0){
		        $loadd = '<p class="label" style="color:red;">There is no fixed period</p>';
			}
		    if($store['store_time'] == 1){
		        $loadd = '<p class="label" style="color:red;">The duration of membership is 7 days</p>';
		    }
		    if($store['store_time'] == 2){
		        $loadd = '<p class="label" style="color:red;">15-day membership period</p>';
		    }
		    if($store['store_time'] == 3){
		        $loadd = '<p class="label" style="color:red;">30-day membership period</p>';
			}
		}
	}
	else {
    	return false;
	}
	return $loadd;
}

// premium time
function premiumNewTime($plan, $user){
	if($plan == 1){
		$time1 = strtotime('+7 days', time());
	}
	else if($plan == 2){
		$time1 = strtotime('+15 days', time());
	}
	else if($plan == 3){
		$time1 = strtotime('+1 month', time());
	}
	else if($plan == 4){
		$time1 = strtotime('+6 months', time());
	}
	else if($plan == 5){
		$time1 = strtotime('+1 year', time());
	}
	else {
		$time1 = $user['vip_end'];
	}
	return $time1;
}
function premiumDate($date){
	return date("Y-m-d", $date);
}
function premiumEndingDate($val){
	global $lang;
	if($val == 0){
		return 'Life time';
	}
	else {
		return '<i class="fa fa-clock-o error"></i> ' .  premiumDate($val);
	}
}

//=== Profile colors
function proGradChoices($sel, $type, $min = 1){
	global $cody;
	$show_c = '';
	switch($type){
		case 4:
			$c = 'pro_choice';
			break;
		default:
			return false;
	}
	for ($n = $min; $n <= 80; $n++) {
		$val = 'pgrad' . $n;
		$back = 'prograd' . $n;
		$add_sel = '';
		if($val == $sel){
			$add_sel = '<i class="bccheck fa fa-check"></i>';
		}
		$show_c .= '<div data="' . $val . '" class="color_switch ' . $c . ' ' . $back . '">' . $add_sel . '</div>';
	}
	return $show_c;
}
function proShadowGradChoices($sel, $type, $min = 1){
	global $cody;
	$show_c = '';
	switch($type){
		case 4:
			$c = 'pro_shadow';
			break;
		default:
			return false;
	}
	for ($n = $min; $n <= 45; $n++) {
		$val = 'shgrad' . $n;
		$back = 'shback' . $n;
		$add_sel = '';
		if($val == $sel){
			$add_sel = '<i style="color:red;" class="bccheck fa fa-check"></i>';
		}
		$show_c .= '<div data="' . $val . '" class="color_switch ' . $c . ' ' . $back . '">' . $add_sel . '</div>';
	}
	return $show_c;
}
function picBoxShadow($sel, $type, $min = 1){
	global $cody;
	$show_c = '';
	switch($type){
		case 4:
			$c = 'pic_shadow';
			break;
		default:
			return false;
	}
	for ($n = $min; $n <= 45; $n++) {
		$val = 'picshadw' . $n;
		$back = 'picback' . $n;
		$add_sel = '';
		if($val == $sel){
			$add_sel = '<i class="bccheck fa fa-check"></i>';
		}
		$show_c .= '<div data="' . $val . '" class="color_switch ' . $c . ' ' . $back . '">' . $add_sel . '</div>';
	}
	return $show_c;
}

// animation gradient
function gradyChoice($sel, $type, $min = 1){
	$show_c = '';
	switch($type){
		case 1:
			$c = 'choice';
			break;
		case 2:
			$c = 'user_choice';
			break;
		case 3:
			$c = 'name_choices';
			break;
		default:
			return false;
	}
	for ($n = $min; $n <= 80; $n++) {
		$val = 'bgrad' . $n;
		$back = 'backgrad' . $n;
		$add_sel = '';
		if($val == $sel){
			$add_sel = '<i class="bccheck fa fa-check"></i>';
		}
		$show_c .= '<div data="' . $val . '" class="color_switch ' . $c . ' ' . $back . '">' . $add_sel . '</div>';
	}
	return $show_c;
}

// names shadow
function myNameShadow($sel, $type, $min = 1){
	$show_c = '';
	switch($type){
		case 1:
			$c = 'choice';
			break;
		case 2:
			$c = 'user_choice';
			break;
		case 3:
			$c = 'name_shadow';
			break;
		default:
			return false;
	}
	for ($n = $min; $n <= 35; $n++) {
		$val = 'tshadow' . $n;
		$back = 'bshadow' . $n;
		$add_sel = '';
		if($val == $sel){
			$add_sel = '<i class="bccheck fa fa-check"></i>';
		}
		$show_c .= '<div data="' . $val . '" class="color_switch ' . $c . ' ' . $back . '">' . $add_sel . '</div>';
	}
	return $show_c;
}

function getMyBadges(){
	global $mysqli, $data, $lang;
	$loadd = '';
	$get_badge = $mysqli->query("SELECT * FROM boom_badge WHERE user_id = '{$data['user_id']}'");
	if($get_badge->num_rows > 0){
		while($badge = $get_badge->fetch_assoc()){
			$loadd .= '<div onclick="saveMyBadge('. $badge['badge_img'] .');" title="'. $badge['badge_title'] .'" class="predefined_avatar_layout">
                        <img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/badges/'. $badge['badge_img'] .'"></div>';
		}
	}
	else {
    	$loadd .= emptyZone($lang['no_data']);
	}
	return $loadd;
}
function systemPostNews($user, $news){
	global $mysqli, $data;
	$mysqli->query("INSERT INTO `boom_news` (news_poster, news_message, news_date) VALUES ('$user', '$news', '" . time() . "')");
	$mysqli->query("UPDATE boom_users SET user_news = '". time() ."', naction = naction + 1 WHERE user_id = '2'"); 
	chatAction($data['user_roomid']);
	return true;
}
?>