<?php 
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');

if(!isset($_POST['target'])){
	echo 0;
	die();
}
$target = escape($_POST['target']);
$user = userDetails($target);

if(!boomAllow(11)){
	die();
}
?>
<div class="pad20">
	<p style="color: blue;" class="label">Upgrade to Premium Membership</p>
	<select id="upgrade_premium_user" onchange="upgradeUserPremium(<?php echo $user['user_id']; ?>);">
		<option <?php echo selCurrent($user['user_prim'], 0); ?> value="0">No premium</option>
		<option <?php echo selCurrent($user['user_prim'], 1); ?> value="1">7 Days</option>
		<option <?php echo selCurrent($user['user_prim'], 2); ?> value="2">15 Days</option>
		<option <?php echo selCurrent($user['user_prim'], 3); ?> value="3">1 Month</option>
		<option <?php echo selCurrent($user['user_prim'], 4); ?> value="4">6 Months</option>
		<option <?php echo selCurrent($user['user_prim'], 5); ?> value="5">1 Year</option>
	</select>
	<p style="color: red;" class="label">Upgrade to Premium Membership</p>
	<select id="upgrade_premiumplus_user" onchange="upgradeUserPremiumPlus(<?php echo $user['user_id']; ?>);">
		<option <?php echo selCurrent($user['prim_plus'], 0); ?> value="0">No premium</option>
		<option <?php echo selCurrent($user['prim_plus'], 1); ?> value="1">7 Days</option>
		<option <?php echo selCurrent($user['prim_plus'], 2); ?> value="2">15 Days</option>
		<option <?php echo selCurrent($user['prim_plus'], 3); ?> value="3">1 Month</option>
		<option <?php echo selCurrent($user['prim_plus'], 4); ?> value="4">6 Months</option>
		<option <?php echo selCurrent($user['prim_plus'], 5); ?> value="5">1 Year</option>
	</select>
</div>