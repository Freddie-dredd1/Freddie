<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');

if (!boomAllow(10)) {
    die();
}
$leader_list = '';
function getHistory($add, $rank){
    global $lang;
    $user = userDetails($add['hunter']);
	return '<div class="ulist_item">
	            <div class="ulist_avatar">
                    ' . chatDate($add['cdate']) . '
                </div>
                <div class="get_info ulist_avatar" data="' . $user['user_id'] . '">
                    <img src="' . myavatar($user['user_tumb']) . '"/>
                </div>
                <div class="ulist_name username ' . $user['user_color'] . '">
                    ' . $user["user_name"] . '
                </div>
                <div style="display: block;" class="ulist_name username">
                    ' . $add["ctype"] . '
                </div>
            </div>';
}

$get_leader = $mysqli->query("SELECT * FROM boom_console WHERE reason = 'coins_gift' ORDER BY cdate DESC LIMIT 100");
if($get_leader->num_rows > 0){
	$rank = 1;
	while($add = $get_leader->fetch_assoc()){
		$leader_list .= getHistory($add, $rank);
		$rank++;
	}
}
else {
	$leader_list .= emptyZone($lang['no_data']);
}
?>
<div class="ulist_container">
	<?php echo $leader_list; ?>
</div>