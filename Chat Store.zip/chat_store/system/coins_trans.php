<?php
   $load_addons = 'chat_store';
   require_once('../../../system/config_addons.php');
   if(!boomAllow(1)){
       die();
   }
   if(!isset($_POST['target'])){
      echo 0;
      die();
   }
   $target = escape($_POST['target']);
   $user = userDetails($target);
?>
<div class="pad_box">
   <div class="color_choices" data="bgcolor4">
      <div class="reg_menu_container">
         <div class="reg_menu">
            <ul>
                <?php if(boomAllow($data['allow_sendcoins'])){ ?>
               <li class="reg_menu_item reg_selected" data="staff_list" data-z="owner">send coins</li>
               <?php } ?>
               <?php if(boomAllow($data['allow_takecoins'])){ ?>
               <li class="reg_menu_item" data="staff_list" data-z="superadmin">Coins discount</li>
               <?php } ?>
            </ul>
         </div>
      </div>
      <div id="staff_list">
         <div id="owner" class="reg_zone vpad5">
            <div id="container_user">
               <div id="usersnames">
                  <div class="online_user">
                  <p class="label">Choose the number of coins you want to send</p>
                	<select id="send_my_coins">
                      <option value="50">50 coins</option>
                      <option value="100">100 coins</option>
                      <option value="200">200 coins</option>
                      <option value="300">300 coins</option>
                      <option value="400">400 coins</option>
                      <option value="500">500 coins</option>
                      <option value="1000">1000 coins</option>
                      <option value="2000">2000 coins</option>
                      <option value="3000">3000 coins</option>
                      <option value="4000">4000 coins</option>
                      <option value="5000">5000 coins</option>
                   </select>
                	<input type="hidden" id="target" value="<?php echo $user['user_id']; ?>" class="full_input"/>               
                	<div class="pad10">
                	    <button onclick="sendMyCoins();" class="reg_button theme_btn"><i class="fa fa-bitcoin"></i>Send</button>
                	</div>
                  </div>
               </div>
            </div>
            <div class="clear"></div>
         </div>
         <div id="superadmin" class="reg_zone vpad5 hide_zone">
            <div id="container_user">
               <div id="usersnames">
                  <div class="online_user">
                  <p class="label">Type the number of coins you want to deduct</p>
                	<input type="number" id="take_my_coins" class="full_input"/>
                	<input type="hidden" id="target" value="<?php echo $user['user_id']; ?>" class="full_input"/>               
                	<div class="pad10">
                	    <button onclick="takeMyCoins();" class="reg_button theme_btn"><i class="fa fa-bitcoin"></i> Discount</button>
                	</div>
                  </div>
               </div>
            </div>
            <div class="clear"></div>
         </div>
      </div>
   </div>
   <div class="clear"></div>
</div>