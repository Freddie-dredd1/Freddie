<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');

?>
<?php echo elementTitle($data['addons'], 'loadLob(\'admin/setting_addons.php\');'); ?>
<div class="page_full">
    <div>
        <div class="tab_menu">
            <ul>
                <li class="tab_menu_item tab_selected" data="korsy" data-z="korsy_setting"><i class="fa fa-cogs"></i> <?php echo $lang['settings']; ?></li>
                <li class="tab_menu_item" data="korsy" data-z="edara"><i class="fa fa-user-plus"></i> Administrative Memberships</li>
                <li class="tab_menu_item" data="korsy" data-z="prime"><i class="fa fa-diamond"></i>Premium</li>
                <li class="tab_menu_item" data="korsy" data-z="btc"><i class="fa fa-btc"></i> Coins gifts</li>
            </ul>
        </div>
    </div>
    <div class="page_element">
        <div id="korsy" class="tpad15">
            <div id="korsy_setting" class="tab_zone">
                <div class="setting_element ">
                    <p class="label">Select the rank the rank can use the store</p>
                    <select id="set_addon_access">
                        <?php echo listRank($data['addons_access'], 1); ?>
                    </select>
                </div>
                <div class="setting_element ">
                    <p class="label">Select the rank that can send coins</p>
                    <select id="set_allow_sendcoins">
                        <?php echo listRank($data['allow_sendcoins'], 1); ?>
                    </select>
                </div>
                <div class="setting_element ">
                    <p class="label">Select the rank that can deduct coins</p>
                    <select id="set_allow_takecoins">
                        <?php echo listRank($data['allow_takecoins'], 1); ?>
                    </select>
                </div>
                <button onclick="saveSettings();" type="button" class="clear_top reg_button theme_btn"><i class="fa fa-floppy-o"></i> <?php echo $lang['save']; ?></button><br>
            </div>
            <div id="edara" class="tab_zone hide_zone">
                <div class="sub_list_item" id="found1">
                    <div class="sub_list_avatar">
                        <img style="width: 20px;" src="<?php echo $data['domain']; ?>/default_images/rank/vip.svg">
                    </div>
                    <div class="sub_list_name">
                        <p class="edara_name1 username"><?php echo chooseStoreItem(1); ?></p>
                    </div>
                    <div onclick="editEdaraMember(1);" class="sub_list_option">
                        <i class="fa fa-edit edit_btn"></i>
                    </div>
                </div>
                <div class="sub_list_item" id="found1">
                    <div class="sub_list_avatar">
                        <img style="width: 20px;" src="<?php echo $data['domain']; ?>/default_images/rank/mod.svg">
                    </div>
                    <div class="sub_list_name">
                        <p class="edara_name2 username"><?php echo chooseStoreItem(2); ?></p>
                    </div>
                    <div onclick="editEdaraMember(2);" class="sub_list_option">
                        <i class="fa fa-edit edit_btn"></i>
                    </div>
                </div>
                <div class="sub_list_item" id="found1">
                    <div class="sub_list_avatar">
                        <img style="width: 20px;" src="<?php echo $data['domain']; ?>/default_images/rank/admin.svg">
                    </div>
                    <div class="sub_list_name">
                        <p class="edara_name3 username"><?php echo chooseStoreItem(3); ?></p>
                    </div>
                    <div onclick="editEdaraMember(3);" class="sub_list_option">
                        <i class="fa fa-edit edit_btn"></i>
                    </div>
                </div>
            </div>
            <div id="prime" class="tab_zone hide_zone">
                <div class="sub_list_item" id="found1">
                    <div class="sub_list_avatar">
                        <img style="width: auto;height: 30px;" src="<?php echo $data['domain']; ?>/addons/chat_store/files/icons/diamond-circle.png">
                    </div>
                    <div class="sub_list_name">
                        <p class="edara_name1 username"><?php echo chooseStoreItem(4); ?></p>
                    </div>
                    <div onclick="editPrimMember(4);" class="sub_list_option">
                        <i class="fa fa-edit edit_btn"></i>
                    </div>
                </div>
                <div class="sub_list_item" id="found1">
                    <div class="sub_list_avatar">
                        <img style="width: auto;height: 30px;" src="<?php echo $data['domain']; ?>/addons/chat_store/files/icons/diamond-circle.png">
                    </div>
                    <div class="sub_list_name">
                        <p class="edara_name2 username"><?php echo chooseStoreItem(5); ?></p>
                    </div>
                    <div onclick="editPrimMember(5);" class="sub_list_option">
                        <i class="fa fa-edit edit_btn"></i>
                    </div>
                </div>
                <div class="sub_list_item" id="found1">
                    <div class="sub_list_avatar">
                        <img style="width: auto;height: 30px;" src="<?php echo $data['domain']; ?>/addons/chat_store/files/icons/diamond-circle.png">
                    </div>
                    <div class="sub_list_name">
                        <p class="edara_name3 username"><?php echo chooseStoreItem(6); ?></p>
                    </div>
                    <div onclick="editPrimMember(6);" class="sub_list_option">
                        <i class="fa fa-edit edit_btn"></i>
                    </div>
                </div>
            </div>
            <div id="btc" class="tab_zone hide_zone">
                <div class="setting_element ">
                    <p class="label">Write a sentence for the gift</p>
                    <input id="set_coins_gift" class="full_input" type="text" placeholder="Write the gift sentence..." />
                </div>
                <div class="setting_element ">
                    <p class="label">Enter the number of coins for the gift</p>
                    <input id="set_coins_code" class="full_input" type="number" placeholder="Enter the number of coins in the gift..." />
                </div>
                <button type="button" style="background:#d803d1;" onclick="sendCoinsGift();" class="reg_button ok_btn"><i class="fa fa-share"></i> send the gift</button>
                <button onclick="showCoinsGiftHis();" type="button" class="clear_top reg_button theme_btn"><i class="fa fa-floppy-o"></i>Gift review</button>
            </div>
        </div>
        <div class="config_section">
            <script data-cfasync="false" type="text/javascript">
                loadStore = function(p) {
                    hideAll();
                    $.post('addons/chat_store/system/' + p, {
                        token: utk,
                    }, function(response) {
                        $('#page_wrapper').html(response);
                        selectIt();
                        pageTop();
                    });
                }
                saveSettings = function() {
                    $.post('addons/chat_store/system/action.php', {
                        set_addon_access: $('#set_addon_access').val(),
                        set_allow_sendcoins: $('#set_allow_sendcoins').val(),
                        set_allow_takecoins: $('#set_allow_takecoins').val(),
                        token: utk,
                    }, function(response) {
                        if (response == 1) {
                            callSaved('New settings saved', 1);
                            loadStore('config.php');
                        } else {
                            callSaved(system.error, 3);
                        }
                    });
                }
                editEdaraMember = function(edara) {
                    $.post('addons/chat_store/system/edit_edara.php', {
                        edara_member: edara,
                        token: utk,
                    }, function(response) {
                        if (response == 0) {
                            callSaved(system.error, 3);
                        } else {
                            overModal(response, 350);
                        }
                    });
                }
                editPrimMember = function(prime) {
                    $.post('addons/chat_store/system/edit_prim.php', {
                        prime_member: prime,
                        token: utk,
                    }, function(response) {
                        if (response == 0) {
                            callSaved(system.error, 3);
                        } else {
                            overModal(response, 350);
                        }
                    });
                }
                showCoinsGiftHis = function() {
                    $.post('addons/chat_store/system/coins_gift_history.php', {
                        token: utk,
                    }, function(response) {
                        if (response == 0) {
                            callSaved(system.error, 3);
                        } else {
                            overModal(response, 350);
                        }
                    });
                }
                saveStorePrim = function() {
                    $.post('addons/chat_store/system/action.php', {
                        set_store_Primitem1: $('#set_store_Primitem1').val(),
                        set_store_Priminfo1: $('#set_store_Priminfo1').val(),
                        set_store_Primprice1: $('#set_store_Primprice1').val(),
                        set_store_Primlevel1: $('#set_store_Primlevel1').val(),
                        set_store_Primitem2: $('#set_store_Primitem2').val(),
                        set_store_Priminfo2: $('#set_store_Priminfo2').val(),
                        set_store_Primprice2: $('#set_store_Primprice2').val(),
                        set_store_Primlevel2: $('#set_store_Primlevel2').val(),
                        set_store_Primitem3: $('#set_store_Primitem3').val(),
                        set_store_Priminfo3: $('#set_store_Priminfo3').val(),
                        set_store_Primprice3: $('#set_store_Primprice3').val(),
                        set_store_Primlevel3: $('#set_store_Primlevel3').val(),
                        token: utk,
                    }, function(response) {
                        if (response == 1) {
                            callSaved(', 1The new settings have been saved');
                        } else {
                            callSaved(system.error, 3);
                        }
                    });
                }
                sendCoinsGift = function() {
                    $.post('addons/chat_store/system/action.php', {
                        set_coins_gift: $('#set_coins_gift').val(),
                        set_coins_code: $('#set_coins_code').val(),
                        token: utk,
                    }, function(response) {
                        if (response == 1) {
                            callSaved('1,The Gift Has Been Send');
                        } else {
                            callSaved(system.error, 3);
                        }
                    });
                }
                resetUsersCoins = function() {
                    if (confirm("Are you sure you want to delete all member coins?")) {
                        $.post('addons/chat_store/system/action.php', {
                            resetcoins: 1,
                            token: utk,
                        }, function(response) {
                            if (response == 1) {
                            callSaved('1,The new Setting Has Been Saved');
                            } else {
                                callSaved(system.error, 3);
                            }
                        });
                    } else {
                        return false;
                    }
                }
            </script>
        </div>
    </div>
</div>