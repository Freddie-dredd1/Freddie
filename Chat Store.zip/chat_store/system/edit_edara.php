<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');

if (!boomAllow(10)) {
    die();
}
$mem = escape($_POST['edara_member']);
?>
<div class="pad_box">
    <div class="boom_form">
        <p class="label">Member Name</p>
        <input type="text" id="new_edara_name" value="<?php echo chooseStoreItem($mem); ?>" class="full_input" />
        <p class="label">Membership information</p>
        <input type="text" id="new_edara_info" value="<?php echo chooseStoreItemInfo($mem); ?>" class="full_input" />
        <p class="label">Membership price (in coins)</p>
        <input type="text" id="new_edara_price" value="<?php echo chooseStoreItemPrice($mem); ?>" class="full_input" />
        <p class="label">The level to be purchased</p>
        <input type="text" id="new_edara_level" value="<?php echo chooseStoreItemLevel($mem); ?>" class="full_input" />
        <p class="label">Time to expire</p>
        <select id="new_edara_time">
            <option <?php echo selCurrent(exChooseStoreItemTime($mem), 1); ?> value="1">7 days</option>
            <option <?php echo selCurrent(exChooseStoreItemTime($mem), 2); ?> value="2">15 days</option>
            <option <?php echo selCurrent(exChooseStoreItemTime($mem), 3); ?> value="3">30 days</option>
        </select>
    </div>
    <button onclick="saveStoreMems(<?php echo $mem; ?>);" class="reg_button theme_btn"><i class="fa fa-save"></i> <?php echo $lang['save']; ?></button>
    <button class="reg_button default_btn cancel_over"><?php echo $lang['cancel']; ?></button>
</div>
<script>
    loadStore = function(p) {
        hideAll();
        $.post('addons/chat_store/system/' + p, {
            token: utk,
        }, function(response) {
            $('#page_wrapper').html(response);
            selectIt();
            pageTop();
        });
    }
    saveStoreMems = function(edara) {
        $.post('addons/chat_store/system/action.php', {
            edara_member: edara,
            new_edara_name: $('#new_edara_name').val(),
            new_edara_info: $('#new_edara_info').val(),
            new_edara_price: $('#new_edara_price').val(),
            new_edara_level: $('#new_edara_level').val(),
            new_edara_time: $('#new_edara_time').val(),
            token: utk,
        }, function(response) {
            if (response == 1) {
                callSaved('save the new settings', 1);
                hideOver();
                loadStore('config.php');
            } else {
                callSaved(system.error, 3);
            }
        });
    }
</script>