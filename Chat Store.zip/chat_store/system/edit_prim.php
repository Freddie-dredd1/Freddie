<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');

if (!boomAllow(10)) {
    die();
}
$mem = escape($_POST['prime_member']);
?>
<div class="pad_box">
    <div class="boom_form">
        <p class="label">Member Name</p>
        <input type="text" id="new_prime_name" value="<?php echo chooseStoreItem($mem); ?>" class="full_input" />
        <p class="label">Membership information</p>
        <input type="text" id="new_prime_info" value="<?php echo chooseStoreItemInfo($mem); ?>" class="full_input" />
        <p class="label">Membership price (in coins)</p>
        <input type="text" id="new_prime_price" value="<?php echo chooseStoreItemPrice($mem); ?>" class="full_input" />
        <p class="label">The level to be purchased</p>
        <input type="text" id="new_prime_level" value="<?php echo chooseStoreItemLevel($mem); ?>" class="full_input" />
    </div>
    <button onclick="saveStorePrime(<?php echo $mem; ?>);" class="reg_button theme_btn"><i class="fa fa-save"></i> <?php echo $lang['save']; ?></button>
    <button class="reg_button default_btn cancel_over"><?php echo $lang['cancel']; ?></button>
</div>
<script>
    loadStore = function(p) {
        hideAll();
        $.post('addons/chat_store/system/' + p, {
            token: utk,
        }, function(response) {
            $('#page_wrapper').html(response);
            selectIt();
            pageTop();
        });
    }
    saveStorePrime = function(prime) {
        $.post('addons/chat_store/system/action.php', {
            prime_member: prime,
            new_prime_name: $('#new_prime_name').val(),
            new_prime_info: $('#new_prime_info').val(),
            new_prime_price: $('#new_prime_price').val(),
            new_prime_level: $('#new_prime_level').val(),
            new_prime_time: $('#new_prime_time').val(),
            token: utk,
        }, function(response) {
            if (response == 1) {
                callSaved('New settings saved', 1);
                hideOver();
                loadStore('config.php');
            } else {
                callSaved(system.error, 3);
            }
        });
    }
</script>