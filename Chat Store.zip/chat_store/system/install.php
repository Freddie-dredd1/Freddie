<?php
if(!defined('BOOM')){
	die();
}
if(boomAllow(10)){
	$ad = array(
	'name' => 'chat_store',
	'access'=> 11,
	);
}

?>