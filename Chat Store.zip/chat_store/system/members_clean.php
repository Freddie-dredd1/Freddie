<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');

function memberUserClean(){
	global $mysqli, $data;
	$time = time();
	$get_premium = $mysqli->query("SELECT * FROM boom_users WHERE user_rank > 1 and sup_end < $time and sup_end > 0");
	if($get_premium->num_rows > 0){	
		while($user = $get_premium->fetch_assoc()){
			    $mysqli->query("UPDATE boom_users SET user_rank = '1', sup_end = 0 WHERE user_id = '{$user['user_id']}'");
		}
		return 1;
	}
	else {
		return 0;
	}
}
if(isset($_POST['clean_members']) && boomAllow(1)){
	echo memberUserClean();
	die();
}
?>