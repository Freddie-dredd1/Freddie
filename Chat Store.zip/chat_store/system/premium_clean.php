<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');

function premiumUserClean(){
	global $mysqli, $data;
	$time = time();
	$get_premium = $mysqli->query("SELECT * FROM boom_users WHERE user_prim > 0 and prim_end < $time and prim_end > 0");
	if($get_premium->num_rows > 0){	
		while($user = $get_premium->fetch_assoc()){
			    $mysqli->query("UPDATE boom_users SET user_prim = '0', prim_end = 0 WHERE user_id = '{$user['user_id']}'");
			    resetUserPrim($user);
		}
		return 1;
	}
	else {
		return 0;
	}
}
if(isset($_POST['clean_premium']) && boomAllow(1)){
	echo premiumUserClean();
	die();
}
?>