<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');

function premiumPlusUserClean(){
	global $mysqli, $data;
	$time = time();
	$get_premium = $mysqli->query("SELECT * FROM boom_users WHERE prim_plus > 0 and prim_plus_end < $time and prim_plus_end > 0");
	if($get_premium->num_rows > 0){	
		while($user = $get_premium->fetch_assoc()){
			    $mysqli->query("UPDATE boom_users SET prim_plus = '0', prim_plus_end = 0 WHERE user_id = '{$user['user_id']}'");
			    resetUserPrimPlus($user);
		}
		return 1;
	}
	else {
		return 0;
	}
}
if(isset($_POST['clean_premium_plus']) && boomAllow(1)){
	echo premiumPlusUserClean();
	die();
}
?>