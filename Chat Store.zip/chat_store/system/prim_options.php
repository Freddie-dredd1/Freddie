<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');
if (!canManagePremium()) {
	die();
}
?>
<style>
	.sp-replacer {
		width: 100%;
	}

	.sp-dd {
		float: right;
	}

	.box_height {
		max-height: 150px;
	}

	.preview_zone {
		padding: 5px 0 20px 0;
		margin-bottom: 20px;
	}
</style>
<div class="pad_box">
	<div class="color_choices" data="bgcolor4">
		<div style="background: #ededed;" class="reg_menu_container">
			<h3 style="text-align: center;color: blue;padding:3px 0px;">Premium Features</h3>
			<div style="text-align: center;color: white;padding:3px 0px;border-radius:25px;" class="reg_menu chat_head">
				<ul>
					<li class="reg_menu_item reg_selected" data="staff_list" data-z="owner"><i class="fa fa-text-width"></i></li>
					<li class="reg_menu_item" data="staff_list" data-z="superadmin"><i class="fa fa-music"></i></li>
					<li class="reg_menu_item" data="staff_list" data-z="mod"><i class="fa fa-paint-brush"></i></li>
					<li class="reg_menu_item" data="staff_list" data-z="mod2"><i class="fa fa-smile-o"></i></li>
					<li class="reg_menu_item" data="staff_list" data-z="mod3"><i class="fa fa-image"></i></li>
					<li class="reg_menu_item" data="staff_list" data-z="mod4"><i class="fa fa-facebook"></i></li>
				</ul>
			</div>
		</div>
		<?php if ($data['prim_plus'] > 0) { ?>
			<div style="background: #ededed;" class="reg_menu_container">
				<h3 style="text-align: center;color: red;padding:3px 0px;">Premium Plus Features</h3>
				<div style="text-align: center;color: white;padding:3px 0px;border-radius:25px;" class="reg_menu chat_head">
					<ul>
						<li class="reg_menu_item" data="staff_list" data-z="mod5"><i class="fa fa-free-code-camp"></i></li>
						<li class="reg_menu_item" data="staff_list" data-z="mod8"><i class="fa fa-text-width"></i></li>
						<li class="reg_menu_item" data="staff_list" data-z="mod6"><i class="fa fa-image"></i></li>
						<li class="reg_menu_item" data="staff_list" data-z="mod7"><i class="fa fa-cogs"></i></li>
					</ul>
				</div>
			</div>
		<?php } ?>
		<div id="staff_list">
			<div id="owner" class="reg_zone vpad5">
				<div id="container_user">
					<div id="usersnames">
						<div class="online_user">
							<div class="pad_box">
								<div>
									<p class="label">write a decoration for your name</p>
									<input style="margin-bottom:5px;" type='text' value='<?php echo $data['fancy_name']; ?>' id='set_fancy_name' class='full_input' />
									<p class="label">Choose the name font</p>
									<select id="fancy_font_style">
										<?php echo listNameFont($data['user_font']); ?>
									</select>
									<div class="tpad5 bpad15">
										<button onclick="saveFancySystem();" class="reg_button theme_btn"><i class="fa fa-save"></i>save the decoration</button>
										<button onclick="delFancySystem();" class="reg_button delete_btn"><i class="fa fa-trash"></i>delete decoration </button>
									</div>
								</div>
								<div class="user_color" data="<?php echo $data['user_color']; ?>">
									<div class="reg_menu_container">
										<div class="reg_menu">
											<ul>
												<li class="reg_menu_item reg_selected" data="color_tab" data-z="grad_color">moving color</li>
												<li class="reg_menu_item" data="color_tab" data-z="name_glow">name glow</li>
												<li class="reg_menu_item" data="color_tab" data-z="anim_color">Distinctive shapes</li>
											</ul>
										</div>
									</div>
									<div id="color_tab">
										<div id="grad_color" class="reg_zone vpad5 box_height">
											<?php echo gradyChoice($data['user_color'], 3); ?>
											<div class="clear"></div>
										</div>
										<div id="name_glow" class="reg_zone vpad5 hide_zone">
											<input onchange="saveNameGlow();" type='hidden' value='<?php echo $data['name_glow']; ?>' name='triggerSet' id='name_glow_color' class="full_input" />
											<div class="clear"></div>
										</div>
										<div id="anim_color" class="reg_zone vpad5 hide_zone">
											<div>
												<div id="static_avatars" class="vpad5">
													<?php if ($data['user_language'] == 'English') { ?>
														<div onclick="saveNameWings('yellows-wing1.png', 'yellows-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/yellows-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/yellows-wing1.png"></div>

														<div onclick="saveNameWings('simple-wing1.png', 'simple-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/simple-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/simple-wing1.png"></div>

														<div onclick="saveNameWings('white-wing1.png', 'white-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/white-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/white-wing1.png"></div>

														<div onclick="saveNameWings('frasha-wing1.png', 'frasha-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/frasha-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/frasha-wing1.png"></div>

														<div onclick="saveNameWings('fire-wing1.png', 'fire-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/fire-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/fire-wing1.png"></div>

														<div onclick="saveNameWings('girl-demon-wing1.png', 'girl-demon-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/girl-demon-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/girl-demon-wing1.png"></div>

														<div onclick="saveNameWings('green-wing1.png', 'green-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/green-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/green-wing1.png"></div>

														<div onclick="saveNameWings('blue-wing1.png', 'blue-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/blue-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/blue-wing1.png"></div>

														<div onclick="saveNameWings('demon-wing2.png', 'demon-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/demon-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/demon-wing2.png"></div>

														<div onclick="saveNameWings('lemon-wing2.png', 'lemon-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/lemon-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/lemon-wing2.png"></div>

														<div onclick="saveNameWings('angel-wing2.png', 'angel-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/angel-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/angel-wing2.png"></div>

														<div onclick="saveNameWings('old-green-wing2.png', 'old-green-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/old-green-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/old-green-wing2.png"></div>

														<div onclick="saveNameWings('old-blue-wing2.png', 'old-blue-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/old-blue-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/old-blue-wing2.png"></div>

														<div onclick="saveNameWings('red-wing2.png', 'red-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/red-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/red-wing2.png"></div>

														<div onclick="saveNameWings('gold-wing2.png', 'gold-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/gold-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/gold-wing2.png"></div>
													<?php } ?>
													<?php if ($data['user_language'] != 'Arabic') { ?>
														<div onclick="saveNameWings('yellows-wing2.png', 'yellows-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/yellows-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/yellows-wing2.png"></div>

														<div onclick="saveNameWings('simple-wing2.png', 'simple-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/simple-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/simple-wing2.png"></div>

														<div onclick="saveNameWings('white-wing2.png', 'white-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/white-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/white-wing2.png"></div>

														<div onclick="saveNameWings('frasha-wing2.png', 'frasha-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/frasha-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/frasha-wing2.png"></div>

														<div onclick="saveNameWings('fire-wing2.png', 'fire-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/fire-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/fire-wing2.png"></div>

														<div onclick="saveNameWings('girl-demon-wing2.png', 'girl-demon-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/girl-demon-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/girl-demon-wing2.png"></div>

														<div onclick="saveNameWings('green-wing2.png', 'green-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/green-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/green-wing2.png"></div>

														<div onclick="saveNameWings('blue-wing2.png', 'blue-wing1.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/blue-wing1.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/blue-wing2.png"></div>

														<div onclick="saveNameWings('demon-wing1.png', 'demon-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/demon-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/demon-wing1.png"></div>

														<div onclick="saveNameWings('lemon-wing1.png', 'lemon-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/lemon-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/lemon-wing1.png"></div>

														<div onclick="saveNameWings('angel-wing1.png', 'angel-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/angel-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/angel-wing1.png"></div>

														<div onclick="saveNameWings('old-green-wing1.png', 'old-green-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/old-green-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/old-green-wing1.png"></div>

														<div onclick="saveNameWings('old-blue-wing1.png', 'old-blue-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/old-blue-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/old-blue-wing1.png"></div>

														<div onclick="saveNameWings('red-wing1.png', 'red-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/red-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/red-wing1.png"></div>

														<div onclick="saveNameWings('gold-wing1.png', 'gold-wing2.png');" title="" class="predefined_avatar_layout">
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/gold-wing2.png">
															<span id="priv_wings" class="<?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo $data['user_name']; ?></span>
															<img style="height:25px;vertical-align: bottom;" src="addons/chat_store/files/wing/gold-wing1.png"></div>
													<?php } ?>

												</div>
											</div>
											<div class="clear"></div>
										</div>
									</div>
									<div class="clear"></div>
								</div>
								<div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="superadmin" class="reg_zone vpad5 hide_zone">
				<div id="container_user">
					<div id="usersnames">
						<div class="online_user">
							<div class="setting_element">
								<p class="label"><b style="color:red;">Choose the song from your files</b></p>
								<input id="pro_song" class="full_input" type="file" />
								<p class="sub_text sub_label">The song must be in MP3 format and its size should not exceed 5MB</p>
							</div>
							<div class="pad10">
								<button type="button" onclick="uploadProfileSong();" class="reg_button theme_btn"><i id="avat_icon_song" class="fa fa-floppy-o"></i> <?php echo $lang['save']; ?></button>
								<button type="button" onclick="delProfileSong();" class="reg_button delete_btn"><i class="fa fa-times"></i>delete the song</button>
							</div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="mod" class="reg_zone vpad5 hide_zone">
				<div id="container_user">
					<div id="usersnames">
						<div class="online_user">
							<p class="label">Main text color</p>
							<input type='hidden' value='<?php echo $data['pro_text_main']; ?>' name='triggerSet' id='pro_text_main' class="full_input" />
							<p class="label">subtext color</p>
							<input type='hidden' value='<?php echo $data['pro_text_sub']; ?>' name='triggerSet' id='pro_text_sub' class="full_input" />
							<p class="label">Profile Lists Rectangle Color</p>
							<input type='hidden' value='<?php echo $data['pro_text_menu']; ?>' name='triggerSet' id='pro_text_menu' class="full_input" />
							<div class="pad10">
								<button type="button" onclick="saveProSettings();" class="reg_button default_btn"><i class="fa fa-save"></i>save colors</button>
							</div>
							<p class="label">background image for profile</p>
							<input id="pro_background" class="full_input" type="file" />
							<div class="pad10">
								<button type="button" onclick="uploadProBackground();" class="reg_button default_btn"><i id="pro_bg_icon" class="fa fa-save"></i>background lift</button>
							</div>
							<p class="label">Profile color</p>
							<div data="<?php echo $data['pro_color']; ?>" class="my_pro_color vpad5 box_height">
								<?php echo proGradChoices($data['pro_color'], 4); ?>
								<div class="clear"></div>
							</div>
							<p class="label">profile glow</p>
							<div data="<?php echo $data['pro_shadow']; ?>" class="my_pro_shadow vpad5 box_height">
								<?php echo proShadowGradChoices($data['pro_shadow'], 4); ?>
								<div class="clear"></div>
							</div>
							<div class="pad10">
								<button type="button" onclick="delProColors();" class="reg_button delete_btn"><i class="fa fa-trash"></i>default profile</button>
							</div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="mod2" class="reg_zone vpad5 hide_zone">
				<div id="container_user">
					<div id="usersnames">
						<div class="online_user">
							<div class="gift-responsive" onclick="saveNameSmile(1)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 46px; height: 46px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0px;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3312" style="position: absolute; top: 0px; left: 0px; width: 238464px; height: 46px; animation: 6s steps(72) 0s infinite normal none running sm_3312; background: url(addons/chat_store/files/smiles/1.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(4)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 50px; height: 50px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0px;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 259200px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/2.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(6)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 48px; height: 48px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0px;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3456" style="position: absolute; top: 0px; left: 0px; width: 248832px; height: 48px; animation: 6s steps(72) 0s infinite normal none running sm_3456; background: url(addons/chat_store/files/smiles/3.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(7)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 34px; height: 34px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0px;"><span data-animation="6s steps(72) 0s infinite normal none running sm_2448" style="position: absolute; top: 0px; left: 0px; width: 176256px; height: 34px; animation: 6s steps(72) 0s infinite normal none running sm_2448; background: url(addons/chat_store/files/smiles/4.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(8)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 50px; height: 50px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0px;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 259200px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/5.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(9)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 48px; height: 48px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0px;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3456" style="position: absolute; top: 0px; left: 0px; width: 248832px; height: 48px; animation: 6s steps(72) 0s infinite normal none running sm_3456; background: url(addons/chat_store/files/smiles/6.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(10)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 44px; height: 44px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0px;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3168" style="position: absolute; top: 0px; left: 0px; width: 228096px; height: 44px; animation: 6s steps(72) 0s infinite normal none running sm_3168; background: url(addons/chat_store/files/smiles/7.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(11)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 36px; height: 36px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0px;"><span data-animation="3s steps(36) 0s infinite normal none running sm_1296" style="position: absolute; top: 0px; left: 0px; width: 46656px; height: 36px; animation: 3s steps(36) 0s infinite normal none running sm_1296; background: url(addons/chat_store/files/smiles/8.png) no-repeat;"></span></span></div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(12)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 34px; height: 34px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0;"><span data-animation="1.5s steps(18) 0s infinite normal none running sm_612" style="position: absolute; top: 0px; left: 0px; width: 11016px; height: 34px; animation: 1.5s steps(18) 0s infinite normal none running sm_612; background: url(addons/chat_store/files/smiles/9.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(13)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 44px; height: 44px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3168" style="position: absolute; top: 0px; left: 0px; width: 228096px; height: 44px; animation: 6s steps(72) 0s infinite normal none running sm_3168; background: url(addons/chat_store/files/smiles/10.png) no-repeat;"></span></span>

									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(14)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 50px; height: 50px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 259200px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/11.png) no-repeat;"></span></span>

									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(15)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 50px; height: 50px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 259200px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/12.png) no-repeat;"></span></span>

									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(16)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 46px; height: 46px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3312" style="position: absolute; top: 0px; left: 0px; width: 238464px; height: 46px; animation: 6s steps(72) 0s infinite normal none running sm_3312; background: url(addons/chat_store/files/smiles/13.png) no-repeat;"></span></span>

									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(17)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 50px; height: 50px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 259200px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/14.png) no-repeat;"></span></span>

									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(18)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 40px; height: 40px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_2880" style="position: absolute; top: 0px; left: 0px; width: 207360px; height: 40px; animation: 6s steps(72) 0s infinite normal none running sm_2880; background: url(addons/chat_store/files/smiles/15.png) no-repeat;"></span></span>

									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(19)">
								<div class="gift-container">
									<div style="height:60px;"><span style="transform: scale(0.7, 0.7); display: inline-block; width: 50px; height: 50px; overflow: hidden; position: relative; margin-top: 0px; margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 3600px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/16.png) no-repeat;"></span></span>

									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(20)">
								<div class="gift-container">
									<div style="height:60px;"><span style="    transform: scale(0.8, 0.8);display: inline-block;width: 45px;height: 50px;overflow: hidden;position: relative;margin-top: 0px;margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 3600px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/17.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(21)">
								<div class="gift-container">
									<div style="height:60px;"><span style="    transform: scale(0.8, 0.8);display: inline-block;width: 45px;height: 50px;overflow: hidden;position: relative;margin-top: 0px;margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3456" style="position: absolute; top: 0px; left: 0px; width: 3456px; height: 48px; animation: 6s steps(72) 0s infinite normal none running sm_3456; background: url(addons/chat_store/files/smiles/18.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(22)">
								<div class="gift-container">
									<div style="height:60px;"><span style="    transform: scale(0.8, 0.8);display: inline-block;width: 45px;height: 50px;overflow: hidden;position: relative;margin-top: 0px;margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3456" style="position: absolute; top: 0px; left: 0px; width: 3456px; height: 48px; animation: 6s steps(72) 0s infinite normal none running sm_3456; background: url(addons/chat_store/files/smiles/19.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="gift-responsive" onclick="saveNameSmile(23)">
								<div class="gift-container">
									<div style="height:60px;"><span style="    transform: scale(0.8, 0.8);display: inline-block;width: 45px;height: 50px;overflow: hidden;position: relative;margin-top: 0px;margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 3600px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/20.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
                          	<div class="gift-responsive" onclick="saveNameSmile(24)">
								<div class="gift-container">
									<div style="height:60px;"><span style="    transform: scale(0.8, 0.8);display: inline-block;width: 45px;height: 50px;overflow: hidden;position: relative;margin-top: 0px;margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 3600px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/21.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
                          	<div class="gift-responsive" onclick="saveNameSmile(25)">
								<div class="gift-container">
									<div style="height:60px;"><span style="    transform: scale(0.8, 0.8);display: inline-block;width: 45px;height: 50px;overflow: hidden;position: relative;margin-top: 0px;margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 3600px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/22.webp) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
                          	<div class="gift-responsive" onclick="saveNameSmile(26)">
								<div class="gift-container">
									<div style="height:60px;"><span style="    transform: scale(0.8, 0.8);display: inline-block;width: 45px;height: 50px;overflow: hidden;position: relative;margin-top: 0px;margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 3600px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/23.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
                          	<div class="gift-responsive" onclick="saveNameSmile(27)">
								<div class="gift-container">
									<div style="height:60px;"><span style="    transform: scale(0.8, 0.8);display: inline-block;width: 45px;height: 50px;overflow: hidden;position: relative;margin-top: 0px;margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 3600px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/24.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
                          	<div class="gift-responsive" onclick="saveNameSmile(28)">
								<div class="gift-container">
									<div style="height:60px;"><span style="    transform: scale(0.8, 0.8);display: inline-block;width: 45px;height: 50px;overflow: hidden;position: relative;margin-top: 0px;margin-left: 0;"><span data-animation="6s steps(72) 0s infinite normal none running sm_3600" style="position: absolute; top: 0px; left: 0px; width: 3600px; height: 50px; animation: 6s steps(72) 0s infinite normal none running sm_3600; background: url(addons/chat_store/files/smiles/25.png) no-repeat;"></span></span>
									</div>
									<div class="gift-desc">Click to use</div>
								</div>
							</div>
							<div class="clear"></div>
							<div class="pad10">
								<button onclick="delNameSmile();" id="clear_sp_smile" class="reg_button delete_btn"><i class="fa fa-trash"></i>delete Emoji</button>
							</div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="mod3" class="reg_zone vpad5 hide_zone">
				<div id="container_user">
					<div id="usersnames">
						<div class="online_user">
							<div class="setting_element">
								<p class="label"><b>Choose the animation from your device</b></p>
								<input id="gif_avatar" class="full_input" type="file" />
							</div>
							<div class="pad10">
								<button type="button" onclick="uploadAvatarGif();" class="reg_button theme_btn"><i id="avat_icon_gif" class="fa fa-camera"></i> <?php echo $lang['save']; ?></button>
							</div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="mod4" class="reg_zone vpad5 hide_zone">
				<div id="container_user">
					<div id="usersnames">
						<div class="online_user">
							<div class="setting_element">
								<p class="label"><i style="color:#0063ff;" class="fa fa-facebook"></i> Facebook</p>
								<input value="<?php echo $data['pro_fb']; ?>" id="set_pro_fb" class="full_input" type="text" />
							</div>
							<div class="setting_element">
								<p class="label"><i style="color:#e613e6;" class="fa fa-instagram"></i> Instagram</p>
								<input value="<?php echo $data['pro_insta']; ?>" id="set_pro_insta" class="full_input" type="text" />
							</div>
							<div class="setting_element">
								<p class="label"><i style="color:#00c1ff;" class="fa fa-twitter"></i> Twitter</p>
								<input value="<?php echo $data['pro_tw']; ?>" id="set_pro_tw" class="full_input" type="text" />
							</div>
							<div class="setting_element">
								<p class="label"><i style="color:#0b9a0b;" class="fa fa-whatsapp"></i> Whatsapp</p>
								<input value="<?php echo $data['pro_wp']; ?>" id="set_pro_wp" class="full_input" type="number" />
							</div>
							<div class="setting_element">
								<p class="label"><i class="fa fa-phone error"></i> Phone</p>
								<input value="<?php echo $data['pro_phone']; ?>" id="set_pro_phone" class="full_input" type="number" />
							</div>
							<div class="pad10">
								<button type="button" onclick="saveProfileSocial();" class="reg_button theme_btn"><i class="fa fa-save"></i> <?php echo $lang['save']; ?></button>
							</div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="mod5" class="reg_zone vpad5 hide_zone">
				<div id="container_user">
					<div id="usersnames">
						<div class="online_user">
							<p class="label">Shadow profile</p>
							<div data="<?php echo $data['pic_shadow']; ?>" class="my_pic_shadow vpad5">
								<?php echo picBoxShadow($data['pic_shadow'], 4); ?>
								<div class="clear"></div>
							</div>
							<div class="pad10">
								<button type="button" onclick="delPicShadow();" class="reg_button delete_btn"><i class="fa fa-trash"></i>remove glow</button>
							</div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="mod8" class="reg_zone vpad5 hide_zone">
				<div id="container_user">
					<div id="usersnames">
					<div class="preview_zone border_bottom">
						<p id="preview_sp_bg"
						style="<?php
						if(!empty($data['sp_bg_width'])){
							echo 'width: '. $data['sp_bg_width'] .'px;';
						}
						?> display: inherit;margin: 0 auto;"
						class="<?php
						if(!empty($data['sp_bg'])){
							echo $data['sp_bg'];
						}
						?> <?php echo $data['user_color']; ?> <?php echo $data['user_font']; ?>"><?php echo (empty($data['fancy_name']) ? $data['user_name'] : $data['fancy_name']); ?></p>
					</div>
						<div class="online_user">
							<p class="label">Zoom in/Zoom out background view</p>
							<input id="set_sp_bg_width" onchange="resizeImage();" type="range" min="90" max="200" value="<?php echo $data['sp_bg_width']; ?>" class="slider">
							<p style="color:red;" class="sub_label border_bottom bpad10">Instructions: Try not to use a very long name so that you can use a background for your name in a coordinated manner. Long names do not appear consistent with the backgrounds.</p>
							<p class="label">Choose the background</p>
							<label><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg1" <?php if($data['sp_bg'] == 'sp_bg1'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/1.gif" height="35px" width="auto" /><br></label>
							<label><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg2" <?php if($data['sp_bg'] == 'sp_bg2'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/2.gif" height="35px" width="auto" /><br></label>
							<label><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg3" <?php if($data['sp_bg'] == 'sp_bg3'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/3.gif" height="35px" width="auto" /><br></label>
							<label><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg4" <?php if($data['sp_bg'] == 'sp_bg4'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/4.gif" height="35px" width="auto" /><br></label>
							<?php if ($data['prim_plus'] >= 2) { ?>
							<label style="border: 1px dashed #ededed;"><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg5" <?php if($data['sp_bg'] == 'sp_bg5'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/5.gif" height="35px" width="auto" /><span class="bold" style="color:#4732c9;font-size:12px;padding-left: 5px;">[PREMIUM PLUS]</span><br></label>
							<?php } ?>
							<?php if ($data['prim_plus'] >= 3 && $data['user_level'] >= 80) { ?>
							<label style="border: 1px dashed #ededed;"><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg6" <?php if($data['sp_bg'] == 'sp_bg6'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/6.gif" height="35px" width="auto" /><span class="bold" style="color:#f9b61c;font-size:12px;padding-left: 5px;">[ROYAL]</span><br></label>
							<?php } ?>
							<?php if ($data['prim_plus'] >= 4 && $data['user_level'] >= 90) { ?>
							<label style="border: 1px dashed #ededed;"><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg7" <?php if($data['sp_bg'] == 'sp_bg7'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/7.gif" height="35px" width="auto" /><span class="bold" style="color:#b8d4fb;font-size:12px;padding-left: 5px;">[SOFTY]</span><br></label>
							<?php } ?>
							<?php if ($data['prim_plus'] == 5 && $data['user_level'] >= 100 && $data['user_prim'] > 0) { ?>
							<label style="border: 1px dashed #ededed;"><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg8" <?php if($data['sp_bg'] == 'sp_bg8'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/8.gif" height="35px" width="auto" /><span class="bold" style="color:#9e84f3;font-size:12px;padding-left: 5px;">[SUPREME]</span><br></label>
							<?php } ?>
							<?php if ($data['prim_plus'] == 5 && $data['user_level'] >= 100 && $data['user_prim'] >= 1) { ?>
							<label style="border: 1px dashed #ededed;"><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg9" <?php if($data['sp_bg'] == 'sp_bg9'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/9.gif" height="35px" width="auto" /><span class="bold" style="color:#fbc12c;font-size:12px;padding-left: 5px;">[EMPEROR]</span><br></label>
							<?php } ?>
							<?php if ($data['prim_plus'] == 5 && $data['user_level'] >= 100 && $data['user_prim'] == 5) { ?>
							<label style="border: 1px dashed #ededed;"><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg10" <?php if($data['sp_bg'] == 'sp_bg10'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/10.gif" height="35px" width="auto" /><span class="bold" style="color:#d534ff;font-size:12px;padding-left: 5px;">[HIGH RANK]</span><br></label>
							<?php } ?>
							<?php if ($data['prim_plus'] == 5 && $data['user_level'] >= 100 && $data['user_prim'] >= 3) { ?>
							<label style="border: 1px dashed #ededed;"><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg11" <?php if($data['sp_bg'] == 'sp_bg11'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/11.gif" height="35px" width="auto" /><span class="bold" style="color:#d9a518;font-size:12px;padding-left: 5px;">[CROWN]</span><br></label>
							<?php } ?>
							<?php if ($data['prim_plus'] == 5 && $data['user_level'] >= 100 && $data['user_prim'] == 5) { ?>
							<label style="border: 1px dashed #ededed;"><input type="radio" name="sp_bg" id="set_sp_bg" value="sp_bg12" <?php if($data['sp_bg'] == 'sp_bg12'){echo 'checked';} ?>/><img src="addons/chat_store/files/sp_bg/12.gif" height="35px" width="auto" /><span class="bold" style="color:#d9a518;font-size:12px;padding-left: 5px;">[ROYAL]</span><br></label>
							<?php } ?>
							<div class="pad10">
								<button type="button" onclick="saveNameSpBg();" class="reg_button ok_btn"><i class="fa fa-save"></i>save settings</button>
								<button type="button" onclick="delNameSpBg();" class="reg_button delete_btn"><i class="fa fa-trash"></i> delete background</button>
							</div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="mod6" class="reg_zone vpad5 hide_zone">
				<div id="container_user">
					<div id="usersnames">
						<div class="online_user box_height" style="max-height: 350px;">
								<div class="gift-responsive" onclick="savePhotoFrame('n-exo.png')" value="n-exo">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-exo.png" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-exp.png')" value="n-exp">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-exp.png" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr-mlky.webp')" value="n-fr-mlky">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr-mlky.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr1.webp')" value="n-fr1">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr1.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr2.webp')" value="n-fr2">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr2.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr3.webp')" value="n-fr3">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr3.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr4.webp')" value="n-fr4">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr4.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr5.webp')" value="n-fr5">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr5.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr6.webp')" value="n-fr6">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr6.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr7.webp')" value="n-fr7">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr7.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr8.webp')" value="n-fr8">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr8.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr9.webp')" value="n-fr9">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr9.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr10.webp')" value="n-fr10">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr10.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr11.webp')" value="n-fr11">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr11.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr13.webp')" value="n-fr13">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr13.webp" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr14.gif')" value="n-fr14">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr14.gif" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr12.png')" value="n-fr12">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr12.png" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr17.png')" value="n-fr17">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr17.png" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr19.png')" value="n-fr19">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr19.png" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr27.png')" value="n-fr27">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr27.png" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
								<div class="gift-responsive" onclick="savePhotoFrame('n-fr28.png')" value="n-fr28">
									<div class="gift-container">
										<div style="height:60px;">
											<img style="height: 55px;width: 50px;padding: 0;" src="addons/chat_store/files/frame/n-fr28.png" />
										</div>
										<div class="gift-desc">Click to use</div>
									</div>
								</div>
							<div class="clear"></div>
						</div>
						<div class="pad10">
							<button onclick="delPhotoFrame();" id="clear_sp_smile" class="reg_button delete_btn"><i class="fa fa-trash"></i> delete frame</button>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="mod7" class="reg_zone vpad5 hide_zone">
				<div id="container_user">
					<div id="usersnames">
						<div class="online_user">
							<div class="setting_element">
								<p class="label"><img style="height:20px;width:auto;vertical-align: bottom;" src="addons/chat_store/files/icons/prim_plus.png"> Close View your profile</p>
								<select id="set_private_profile">
									<option <?php echo selCurrent($data['private_profile'], 0); ?> value="0">Noا</option>
									<option <?php echo selCurrent($data['private_profile'], 1); ?> value="1">Yes</option>
								</select>
							</div>
							<button type="button" onclick="savePrivateProfile();" class="reg_button theme_btn"> <?php echo $lang['save']; ?></button>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<div class="clear"></div>
</div>
<script>
	$("#pro_text_main").spectrum({
		showPaletteOnly: true,
		togglePaletteOnly: true,
		allowEmpty: true,
		togglePaletteMoreText: 'more',
		togglePaletteLessText: 'less',
		showAlpha: true,
		showInput: true,
		showSelectionPalette: true,
		hideAfterPaletteSelect: true,
		showInitial: true,
		preferredFormat: "hex",
		color: '<?php echo $data['pro_text_main']; ?>',
		palette: [
			["#000", "#444", "#666", "#999", "#ccc", "#eee", "#f3f3f3", "#fff"],
			["#f00", "#f90", "#ff0", "#0f0", "#0ff", "#00f", "#90f", "#f0f"],
			["#f4cccc", "#fce5cd", "#fff2cc", "#d9ead3", "#d0e0e3", "#cfe2f3", "#d9d2e9", "#ead1dc"],
			["#ea9999", "#f9cb9c", "#ffe599", "#b6d7a8", "#a2c4c9", "#9fc5e8", "#b4a7d6", "#d5a6bd"],
			["#e06666", "#f6b26b", "#ffd966", "#93c47d", "#76a5af", "#6fa8dc", "#8e7cc3", "#c27ba0"],
			["#c00", "#e69138", "#f1c232", "#6aa84f", "#45818e", "#3d85c6", "#674ea7", "#a64d79"],
			["#900", "#b45f06", "#bf9000", "#38761d", "#134f5c", "#0b5394", "#351c75", "#741b47"],
			["#600", "#783f04", "#7f6000", "#274e13", "#0c343d", "#073763", "#20124d", "#4c1130"]
		]
	});

	// Show the original input to demonstrate the value changing when calling `set`
	$("#pro_text_main").show();
</script>
<script>
	$("#pro_text_sub").spectrum({
		showPaletteOnly: true,
		togglePaletteOnly: true,
		allowEmpty: true,
		togglePaletteMoreText: 'more',
		togglePaletteLessText: 'less',
		showAlpha: true,
		showInput: true,
		showSelectionPalette: true,
		hideAfterPaletteSelect: true,
		showInitial: true,
		preferredFormat: "hex",
		color: '<?php echo $data['pro_text_sub']; ?>',
		palette: [
			["#000", "#444", "#666", "#999", "#ccc", "#eee", "#f3f3f3", "#fff"],
			["#f00", "#f90", "#ff0", "#0f0", "#0ff", "#00f", "#90f", "#f0f"],
			["#f4cccc", "#fce5cd", "#fff2cc", "#d9ead3", "#d0e0e3", "#cfe2f3", "#d9d2e9", "#ead1dc"],
			["#ea9999", "#f9cb9c", "#ffe599", "#b6d7a8", "#a2c4c9", "#9fc5e8", "#b4a7d6", "#d5a6bd"],
			["#e06666", "#f6b26b", "#ffd966", "#93c47d", "#76a5af", "#6fa8dc", "#8e7cc3", "#c27ba0"],
			["#c00", "#e69138", "#f1c232", "#6aa84f", "#45818e", "#3d85c6", "#674ea7", "#a64d79"],
			["#900", "#b45f06", "#bf9000", "#38761d", "#134f5c", "#0b5394", "#351c75", "#741b47"],
			["#600", "#783f04", "#7f6000", "#274e13", "#0c343d", "#073763", "#20124d", "#4c1130"]
		]
	});

	// Show the original input to demonstrate the value changing when calling `set`
	$("#pro_text_sub").show();
</script>
<script>
	$("#pro_text_menu").spectrum({
		showPaletteOnly: true,
		togglePaletteOnly: true,
		allowEmpty: true,
		togglePaletteMoreText: 'more',
		togglePaletteLessText: 'less',
		showAlpha: true,
		showInput: true,
		showSelectionPalette: true,
		hideAfterPaletteSelect: true,
		showInitial: true,
		preferredFormat: "hex",
		color: '<?php echo $data['pro_text_menu']; ?>',
		palette: [
			["#000", "#444", "#666", "#999", "#ccc", "#eee", "#f3f3f3", "#fff"],
			["#f00", "#f90", "#ff0", "#0f0", "#0ff", "#00f", "#90f", "#f0f"],
			["#f4cccc", "#fce5cd", "#fff2cc", "#d9ead3", "#d0e0e3", "#cfe2f3", "#d9d2e9", "#ead1dc"],
			["#ea9999", "#f9cb9c", "#ffe599", "#b6d7a8", "#a2c4c9", "#9fc5e8", "#b4a7d6", "#d5a6bd"],
			["#e06666", "#f6b26b", "#ffd966", "#93c47d", "#76a5af", "#6fa8dc", "#8e7cc3", "#c27ba0"],
			["#c00", "#e69138", "#f1c232", "#6aa84f", "#45818e", "#3d85c6", "#674ea7", "#a64d79"],
			["#900", "#b45f06", "#bf9000", "#38761d", "#134f5c", "#0b5394", "#351c75", "#741b47"],
			["#600", "#783f04", "#7f6000", "#274e13", "#0c343d", "#073763", "#20124d", "#4c1130"]
		]
	});

	// Show the original input to demonstrate the value changing when calling `set`
	$("#pro_text_menu").show();
</script>
<script>
	$("#name_glow_color").spectrum({
		showPaletteOnly: true,
		togglePaletteOnly: true,
		allowEmpty: true,
		togglePaletteMoreText: 'more',
		togglePaletteLessText: 'less',
		showAlpha: true,
		showInput: true,
		showSelectionPalette: true,
		hideAfterPaletteSelect: true,
		showInitial: true,
		preferredFormat: "hex",
		color: '<?php echo $data['name_glow']; ?>',
		palette: [
			["#000", "#444", "#666", "#999", "#ccc", "#eee", "#f3f3f3", "#fff"],
			["#f00", "#f90", "#ff0", "#0f0", "#0ff", "#00f", "#90f", "#f0f"],
			["#f4cccc", "#fce5cd", "#fff2cc", "#d9ead3", "#d0e0e3", "#cfe2f3", "#d9d2e9", "#ead1dc"],
			["#ea9999", "#f9cb9c", "#ffe599", "#b6d7a8", "#a2c4c9", "#9fc5e8", "#b4a7d6", "#d5a6bd"],
			["#e06666", "#f6b26b", "#ffd966", "#93c47d", "#76a5af", "#6fa8dc", "#8e7cc3", "#c27ba0"],
			["#c00", "#e69138", "#f1c232", "#6aa84f", "#45818e", "#3d85c6", "#674ea7", "#a64d79"],
			["#900", "#b45f06", "#bf9000", "#38761d", "#134f5c", "#0b5394", "#351c75", "#741b47"],
			["#600", "#783f04", "#7f6000", "#274e13", "#0c343d", "#073763", "#20124d", "#4c1130"]
		]
	});

	// Show the original input to demonstrate the value changing when calling `set`
	$("#name_glow_color").show();
</script>
<script>
	function resizeImage() {
	var image = document.getElementById('preview_sp_bg'),
		ranger = document.getElementById('set_sp_bg_width');
	image.style.width = ranger.value+'px';
	
	}
</script>