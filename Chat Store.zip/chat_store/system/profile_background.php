<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');


if (!canManagePremium()) {
	die();
}
if (!boomAllow(1)) {
	die();
}

if (isset($_FILES["file"])) {
	ini_set('memory_limit', '128M');
	$info = pathinfo($_FILES["file"]["name"]);
	$extension = $info['extension'];
	$origin = escape(filterOrigin($info['filename']) . '.' . $extension);
	if (fileError()) {
		echo 1;
		die();
	}
	if (isImage($extension)) {
		$imginfo = getimagesize($_FILES["file"]["tmp_name"]);
		if ($imginfo !== false) {

			$width = $imginfo[0];
			$height = $imginfo[1];
			$type = $imginfo['mime'];
			$file_name = encodeFile($extension);
			$find_bg = $mysqli->query("SELECT pro_background FROM boom_users WHERE user_id = '{$data['user_id']}'");
			if ($find_bg->num_rows > 0) {
				$bg            = mysqli_fetch_object($find_bg);
				$old_icon          = $bg->pro_background;
				$sql = boomMoveFile('addons/chat_store/system/upload/' . $file_name);
				$mysqli->query("UPDATE boom_users SET pro_background = '$file_name', pro_color = '' WHERE user_id = '{$data['user_id']}'");
				if ($sql) {
					$path_to_delete = "addons/chat_store/system/upload/" . $old_icon;
					if (file_exists($path_to_delete)) {
						unlink($path_to_delete);
					}
				}
			}
			echo 5;
			die();
		} else {
			echo 1;
			die();
		}
	} else if (isFile($extension)) {
		echo 1;
		die();
	} else if (isMusic($extension)) {
		echo 1;
		die();
	} else {
		echo 1;
	}
} else {
	echo 1;
}
