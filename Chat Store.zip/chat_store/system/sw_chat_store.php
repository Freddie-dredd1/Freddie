<?php
$load_addons = 'chat_store';
require_once('../../../system/config_addons.php');
if (!boomAllow($data['addons_access'])) {
  die();
}
?>
<style>
  .tab_menu {
    background: #2c2b2f;
    color: #ccc;
    font-weight: bold;
  }

  .tab_selected {
    background: #1d1d1d;
  }
</style>
<div style="font-family:flat-jooza;" class="page-event">
  <div class="cover">
    <div class="heading">STORE</div>
  </div>
  <div>
    <div class="tab_menu">
      <ul>
        <li class="tab_menu_item tab_selected" data="store" data-z="store_users"><i class="fa fa-user-plus"></i>Premium Memberships</li>
        <li class="tab_menu_item" data="store" data-z="store_prim"><i class="fa fa-diamond"></i> Premium Memberships</li>
      </ul>
    </div>
  </div>
  <div class="container pad10">
    <div id="store" class="upcoming-event-list ulist_container">
      <div id="store_users" class="event-block tab_zone">
        <div class="row" id="store_mem_id1">
          <div style="background: #36353a;padding: 10px 10px 0px 10px;border-radius: 5px;border-top: 4px solid orange;" class="col-lg-2 sec-1">
            <center>
              <div style="color:#f37171;margin-bottom:5px;font-size:20px;border-bottom: 1px solid white;padding-bottom: 8px;font-weight: bold;" class="month"><?php echo chooseStoreItem(1); ?></div>
            </center></br>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-exclamation-circle"></i> <?php echo chooseStoreItemInfo(1); ?></div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-paypal"></i> the price: <?php echo chooseStoreItemPrice(1); ?> Coins</div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-trophy"></i>The required level : <?php echo chooseStoreItemLevel(1); ?> </div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-clock-o"></i>Expiry time for membership : <?php echo storeItemTime(1); ?> </div>
            <div class="group-of-btn">
              <center>
                <p style="padding:0px 0 10px 0;" class="label"><button id="buy_vip_store" style="width:100%;" type="button" onclick="buyStoreMemberVip();" class="tiny_button ok_btn">Buy Now</button></p>
              </center>
            </div>
          </div>
        </div>

        <div class="row" id="store_mem_id2">
          <div style="background: #36353a;padding: 10px 10px 0px 10px;border-radius: 5px;border-top: 4px solid orange;" class="col-lg-2 sec-1">
            <center>
              <div style="color:#f37171;margin-bottom:5px;font-size:20px;border-bottom: 1px solid white;padding-bottom: 8px;font-weight: bold;" class="month"><?php echo chooseStoreItem(2); ?></div>
            </center></br>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-exclamation-circle"></i> <?php echo chooseStoreItemInfo(2); ?></div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-paypal"></i>The Price : <?php echo chooseStoreItemPrice(2); ?> Coins</div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-trophy"></i> The Required Level : <?php echo chooseStoreItemLevel(2); ?> </div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-clock-o"></i> Expiry Time For Membership : <?php echo storeItemTime(2); ?> </div>
            <div class="group-of-btn">
              <center>
                <p style="padding:0px 0 10px 0;" class="label"><button id="buy_mod_store" style="width:100%;" type="button" onclick="buyStoreMemberMod();" class="tiny_button ok_btn">Buy Now</button></p>
              </center>
            </div>
          </div>
        </div>

        <div class="row" id="store_mem_id3">
          <div style="background: #36353a;padding: 10px 10px 0px 10px;border-radius: 5px;border-top: 4px solid orange;" class="col-lg-2 sec-1">
            <center>
              <div style="color:#f37171;margin-bottom:5px;font-size:20px;border-bottom: 1px solid white;padding-bottom: 8px;font-weight: bold;" class="month"><?php echo chooseStoreItem(3); ?></div>
            </center></br>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-exclamation-circle"></i> <?php echo chooseStoreItemInfo(3); ?></div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-paypal"></i> The Price : <?php echo chooseStoreItemPrice(3); ?> Coins</div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-trophy"></i> The Required Level : <?php echo chooseStoreItemLevel(3); ?> </div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-clock-o"></i> Expiry Time For Membership : <?php echo storeItemTime(3); ?> </div>
            <div class="group-of-btn">
              <center>
                <p style="padding:0px 0 10px 0;" class="label"><button id="buy_adm_store" style="width:100%;" type="button" onclick="buyStoreMemberAdm();" class="tiny_button ok_btn">Buy Now</button></p>
              </center>
            </div>
          </div>
        </div>
        
      </div>
      <div id="store_prim" class="event-block tab_zone hide_zone">
      <div class="row">
          <div style="background: #36353a;padding: 10px 10px 0px 10px;border-radius: 5px;border-top: 4px solid orange;" class="col-lg-2 sec-1">
            <center>
              <div style="color:#f37171;margin-bottom:5px;font-size:20px;border-bottom: 1px solid white;padding-bottom: 8px;font-weight: bold;" class="month"><?php echo chooseStoreItem(4); ?></div>
            </center></br>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-exclamation-circle"></i> <?php echo chooseStoreItemInfo(4); ?></div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-paypal"></i> the price: <?php echo chooseStoreItemPrice(4); ?> Coins</div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-trophy"></i> The required level : <?php echo chooseStoreItemLevel(4); ?> </div>
            <div class="group-of-btn">
              <center>
                <p style="padding:0px 0 10px 0;" class="label"><button id="buy_prem7_store" style="width:100%;" type="button" onclick="buyStorePrem7();" class="tiny_button ok_btn">Buy Now</button></p>
              </center>
            </div>
          </div>
        </div>

        <div class="row">
          <div style="background: #36353a;padding: 10px 10px 0px 10px;border-radius: 5px;border-top: 4px solid orange;" class="col-lg-2 sec-1">
            <center>
              <div style="color:#f37171;margin-bottom:5px;font-size:20px;border-bottom: 1px solid white;padding-bottom: 8px;font-weight: bold;" class="month"><?php echo chooseStoreItem(5); ?></div>
            </center></br>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-exclamation-circle"></i> <?php echo chooseStoreItemInfo(5); ?></div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-paypal"></i> the price: <?php echo chooseStoreItemPrice(5); ?> Coins</div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-trophy"></i> The required level : <?php echo chooseStoreItemLevel(5); ?> </div>
            <div class="group-of-btn">
              <center>
                <p style="padding:0px 0 10px 0;" class="label"><button id="buy_prem15_store" style="width:100%;" type="button" onclick="buyStorePrem15();" class="tiny_button ok_btn">Buy Now</button></p>
              </center>
            </div>
          </div>
        </div>

        <div class="row">
          <div style="background: #36353a;padding: 10px 10px 0px 10px;border-radius: 5px;border-top: 4px solid orange;" class="col-lg-2 sec-1">
            <center>
              <div style="color:#f37171;margin-bottom:5px;font-size:20px;border-bottom: 1px solid white;padding-bottom: 8px;font-weight: bold;" class="month"><?php echo chooseStoreItem(6); ?></div>
            </center></br>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-exclamation-circle"></i> <?php echo chooseStoreItemInfo(6); ?></div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-paypal"></i> the price: <?php echo chooseStoreItemPrice(6); ?> Coins</div>
            <div style="background: #cccccc;color: #212121;padding: 8px;border-radius: 5px;font-weight: bold;margin-top:8px;box-shadow: 0px 0px 10px #36353a;" class="title"><i class="fa fa-trophy"></i> The required level : <?php echo chooseStoreItemLevel(6); ?> </div>
            <div class="group-of-btn">
              <center>
                <p style="padding:0px 0 10px 0;" class="label"><button id="buy_prem30_store" style="width:100%;" type="button" onclick="buyStorePrem30();" class="tiny_button ok_btn">Buy Now</button></p>
              </center>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>