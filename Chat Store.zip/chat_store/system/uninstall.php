<?php
if(boomAllow(11)){

}
?>